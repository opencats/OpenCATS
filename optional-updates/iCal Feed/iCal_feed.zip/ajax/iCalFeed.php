<?php
/*
 * CATS
 * AJAX Data Item Job Orders Interface
 *
 * Custom interface for Elcproperty
 *
 * Written by Mike Eggleston
 * Fenland Software Ltd
 * www.fensoft.co.uk
 *
 * 22nd January 2018
 */


include_once('lib/iCalFeed.php');

    $site = $_GET['s'];
    $user = $_GET['u'];
    $pswd = $_GET['p'];

    // the iCal date format. Note the Z on the end indicates a UTC timestamp.
    define('DATE_ICAL', 'Ymd\THis\Z');

    // max line length is 75 chars. New line is \r\n

    $output = "BEGIN:VCALENDAR\r\nMETHOD:PUBLISH\r\nVERSION:2.0\r\nPRODID:-//Fenland Software//Calendar Feed//EN\r\n";

    $iCal = new iCalFeed();

    $data = $iCal->get( $site, $user, $pswd );

    if( is_array( $data ) ) {

      // loop over events
      foreach( $data as $event ) {

        $output .= sprintf( "BEGIN:VEVENT\r\nSUMMARY:%s\r\n", $event['title'] );
        $output .= sprintf( "DESCRIPTION:%s\r\n", wordwrap( $event['description'], 75, "\r\n", true ) );
        $output .= sprintf( "UID:%d@%s\r\n", $event['calendar_event_id'], $_SERVER['SERVER_NAME'] );

        if( $event['all_day'] ) {
          $output .= sprintf( "DTSTART:%s\r\n", date( DATE_ICAL, strtotime( substr( $event['date'], 0, 11 ) ) ) );
          $output .= sprintf( "DTEND:%s\r\n", date( DATE_ICAL, strtotime( substr( $event['date'], 0, 11 ) . "23:59:59" ) ) );
        } else {
          $output .= sprintf( "DTSTART:%s\r\n", date( DATE_ICAL, strtotime( $event['date'] ) ) );
          if( $event['duration'] >= 0 )
            $output .= sprintf( "DTEND:%s\r\n", date( DATE_ICAL, strtotime( $event['date'] ) + 60 * $event['duration'] ) );
          else
            $output .= sprintf( "DTEND:%s\r\n", date( DATE_ICAL, strtotime( $event['date'] ) ) );
        }
        $output .= sprintf( "LAST-MODIFIED:%s\r\n", date( DATE_ICAL, strtotime($event['date_modified'] ) ) );

        $output .= "END:VEVENT\r\n";
      }
    }

    // close calendar
    $output .= "END:VCALENDAR\r\n";

    header( "Content-type: text/calendar; charset=utf-8" );
    header( "Content-Disposition: inline; filename=calendar.ics" );

    echo $output;

?>
