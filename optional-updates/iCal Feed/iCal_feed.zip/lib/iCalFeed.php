<?php

include_once('./lib/DatabaseConnection.php');
include_once('./lib/UserInterface.php');
include_once('./lib/Users.php');

class iCalFeed
{
    private $_db;

    public function __construct( )
    {
        $this->_db = DatabaseConnection::getInstance();
    }

    public function get( $siteID, $username, $password )
    {
      $u = new Users( $siteID );
      if( $u->isCorrectLogin( $username, $password ) == LOGIN_SUCCESS ) {

        $sql  = sprintf( "SELECT * FROM `calendar_event` WHERE ( `entered_by` = %d OR `public` > 0 ) ", $u->getIDByUsername( $username ) );
        $sql .= "AND `date` > DATE_SUB( curdate(), INTERVAL 1 MONTH )";

        return $this->_db->getAllAssoc( $sql );
      }
    }

}

?>
