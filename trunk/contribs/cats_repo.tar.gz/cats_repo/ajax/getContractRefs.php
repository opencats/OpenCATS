<?php
/*
 * CATS
 * AJAX Company Name Search Interface
 *
 * Copyright (C) 2005 - 2007 Cognizo Technologies, Inc.
 *
 *
 * $Id: getContractRefs.php 2367 2007-04-23 23:24:05Z will $
 */

include_once('./lib/Contracts.php');
include_once('./lib/Search.php');


$interface = new SecureAJAXInterface();

if (!isset($_REQUEST['dataName']))
{
    $interface->outputXMLErrorPage(-1, 'Invalid data name.');
    die();
}

if (!$interface->isRequiredIDValid('maxResults'))
{
    $interface->outputXMLErrorPage(-1, 'Invalid max results count.');
    die();
}

$siteID = $interface->getSiteID();

$dataName   = trim($_REQUEST['dataName']);
$maxResults = $_REQUEST['maxResults'];

$search = new SearchContracts($siteID);
$contractsArray = $search->byName($dataName, 'contract.ref', 'ASC');

if (empty($contractsArray))
{
    $interface->outputXMLErrorPage(-2, 'No contracts data.');
    die();
}

$output =
    "<data>\n" .
    "    <errorcode>0</errorcode>\n" .
    "    <errormessage></errormessage>\n" .
    "    <totalelements>" . count($contractsArray) . "</totalelements>\n";

$arrayCounter = 0;
foreach ($contractsArray as $rowIndex => $row)
{
    $arrayCounter++;

    if ($arrayCounter > $maxResults)
    {
        break;
    }

    $output .=
        "    <result>\n" .
        "        <id>"   . $contractsArray[$rowIndex]['contractID'] . "</id>\n" .
        "        <name>" . rawurlencode($contractsArray[$rowIndex]['ref']) . "</name>\n" .
        "    </result>\n";
}

$output .=
    "</data>\n";

/* Send back the XML data. */
$interface->outputXMLPage($output);

?>
