<?php

/*
 * CATS
 * Companies Datagrid
 *
 * CATS Version: 0.8.0 (Jhelum)
 *
 * Copyright (C) 2005 - 2007 Cognizo Technologies, Inc.
 *
 *
 * The contents of this file are subject to the CATS Public License
 * Version 1.1a (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.catsone.com/. Software distributed under the License is
 * distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is "CATS Standard Edition".
 *
 * The Initial Developer of the Original Code is Cognizo Technologies, Inc.
 * Portions created by the Initial Developer are Copyright (C) 2005 - 2007
 * (or from the year in which this file was created to the year 2007) by
 * Cognizo Technologies, Inc. All Rights Reserved.
 *
 * $Id: dataGrids.php 3566 2007-11-12 09:46:35Z will $
 */

include_once('./lib/Companies.php');
include_once('./lib/Hooks.php');

class ManagementDataGrid extends DataGrid {

    public function __construct($siteID, $parameters, $misc) {
        /* Pager configuration. */
        $this->_tableWidth = 915;
        $this->_defaultAlphabeticalSortBy = 'last_name';
        $this->ajaxMode = false;
        $this->showExportCheckboxes = true;
        $this->showActionArea = false;
        $this->showChooseColumnsBox = false;
        $this->allowResizing = false;
        $this->defaultSortBy = 'last_name';
        $this->defaultSortDirection = 'ASC';

        $this->_defaultColumns = array(
            array('name' => 'Last', 'width' => 100),
            array('name' => 'First', 'width' => 100),
            array('name' => 'Activities count', 'width' => 100),
        );

        $this->_classColumns = array(
            'Last' => array('select' => '',
                'pagerRender' => 'return \'<a href="' . CATSUtility::getIndexName() . '?m=management&amp;a=showUser&amp;userID=\'.$rsData[\'user_id\'].\'">\'.htmlspecialchars($rsData[\'last_name\']).\'</a>\';',
                'sortableColumn' => 'last_name',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
            'First' => array('pagerRender' => 'return \'<a href="' . CATSUtility::getIndexName() . '?m=management&amp;a=showUser&amp;userID=\'.$rsData[\'user_id\'].\'">\'.htmlspecialchars($rsData[\'first_name\']).\'</a>\';',
                'sortableColumn' => 'first_name',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
            'Activities count' => array('pagerRender' => 'return $rsData[\'activities_count\'];',
                'sortableColumn' => 'activities_count',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
        );

        parent::__construct("management:ManagementDataGrid", $parameters, $misc);
    }

    /**
     * Returns the sql statment for the pager.
     *
     * @return array clients data
     */
    public function getSQL($selectSQL, $joinSQL, $whereSQL, $havingSQL, $orderSQL, $limitSQL, $distinct = '') {
        $sql = sprintf(
                "SELECT SQL_CALC_FOUND_ROWS %s
            *,
            activity_count.count as activities_count,
            %s
            FROM
                user
            LEFT JOIN (SELECT count(entered_by) as count, entered_by FROM activity WHERE date_modified > curdate() - interval 7 day GROUP BY entered_by) activity_count ON
                activity_count.entered_by = user.user_id
            %s
            WHERE
             user_id <> 0
            %s
            %s
            %s
            %s", $distinct, $selectSQL, $joinSQL, (strlen($whereSQL) > 0) ? ' AND ' . $whereSQL : '', (strlen($havingSQL) > 0) ? ' HAVING ' . $havingSQL : '', $orderSQL, $limitSQL
        );

        return $sql;
    }
}


class ShowUserDataGrid extends DataGrid {

    public function __construct($siteID, $parameters, $misc) {
        /* Pager configuration. */
        $this->_tableWidth = 915;
        $this->_defaultAlphabeticalSortBy = 'date_modified';
        $this->ajaxMode = false;
        $this->showExportCheckboxes = true;
        $this->showActionArea = false;
        $this->showChooseColumnsBox = false;
        $this->allowResizing = false;
        $this->defaultSortBy = 'date_modified';
        $this->defaultSortDirection = 'DESC';

        $this->_defaultColumns = array(
            array('name' => 'Activity', 'width' => 100),
            array('name' => 'Status', 'width' => 100),
            array('name' => 'Last', 'width' => 100),
            array('name' => 'First', 'width' => 100),
            array('name' => 'Company', 'width' => 100),
            array('name' => 'Date', 'width' => 100),
        );

        $this->_classColumns = array(
            'Activity' => array(
                'pagerRender' => 'return $rsData[\'short_description\'];',
                'sortableColumn' => 'short_description',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
            'Status' => array(
                'select' => 'candidate_joborder_status.short_description as joborder_short_description',
                'pagerRender' => 'return $rsData[\'joborder_short_description\'];',
                'sortableColumn' => 'joborder_short_description',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
            'First' => array(
                'select' => 'candidate.last_name as candidate_last_name',
                'pagerRender' => 'return \'<a href="'.CATSUtility::getIndexName().'?m=candidates&amp;a=show&amp;candidateID=\'.$rsData[\'candidateID\'].\'">\'. $rsData[\'candidate_last_name\'] .\'</a>\';',
                'sortableColumn' => 'candidate_last_name',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
            'Last' => array(
                'select' => 'candidate.first_name as candidate_first_name',
                'pagerRender' => 'return \'<a href="'.CATSUtility::getIndexName().'?m=candidates&amp;a=show&amp;candidateID=\'.$rsData[\'candidateID\'].\'">\'. $rsData[\'candidate_first_name\'] .\'</a>\';',
                'sortableColumn' => 'candidate_first_name',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
            'Company' => array(
                'select' => 'company.name as company_name',
                'pagerRender' => 'return \'<a href="'.CATSUtility::getIndexName().'?m=companies&amp;a=show&companyID=\'.$rsData[\'companyID\'].\'">\'. $rsData[\'company_name\'] .\'</a>\';',
                'sortableColumn' => 'company_name',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
            'Date' => array(
                'pagerRender' => 'return $rsData[\'date_modified\'];',
                'sortableColumn' => 'date_modified',
                'pagerWidth' => 45,
                'pagerOptional' => false,
            ),
        );

        parent::__construct("management:ManagementShowUserDataGrid", $parameters, $misc);
    }

    /**
     * Returns the sql statment for the pager.
     *
     * @return array clients data
     */
    public function getSQL($selectSQL, $joinSQL, $whereSQL, $havingSQL, $orderSQL, $limitSQL, $distinct = '') {
        $userId = (int) $_GET['userID'];
        $sql = sprintf(
              "SELECT SQL_CALC_FOUND_ROWS %s
                activity.*,
                activity_type.*,
                candidate.candidate_id as candidateID,
                joborder.company_id as companyID,
                %s
            FROM
                activity
            JOIN activity_type ON
                activity.type = activity_type.activity_type_id
            JOIN candidate ON
                candidate.candidate_id = activity.data_item_id
            LEFT JOIN candidate_joborder ON
                candidate_joborder.candidate_id = candidate.candidate_id
            LEFT JOIN joborder ON
                candidate_joborder.joborder_id = joborder.joborder_id
            LEFT JOIN candidate_joborder_status ON
                candidate_joborder_status.candidate_joborder_status_id = candidate_joborder.status
            LEFT JOIN company ON
                company.company_id = joborder.company_id

            %s
            WHERE
                activity.date_modified > curdate() - interval 7 day
            AND
                activity.entered_by = %s
            %s
            %s
            %s
            %s",
            $distinct,
            $selectSQL,
            $joinSQL,
            $userId,
            (strlen($whereSQL) > 0) ? ' AND ' . $whereSQL : '',
            (strlen($havingSQL) > 0) ? ' HAVING ' . $havingSQL : '',
            $orderSQL,
            $limitSQL
        );

        return $sql;
    }
}

?>