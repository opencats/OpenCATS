<?php
/*
 * CATS
 * Management World Module (Sample)
 *
 * Copyright (C) 2005 - 2007 Cognizo Technologies, Inc.
 *
 *
 * The contents of this file are subject to the CATS Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.catsone.com/.
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is "CATS Standard Edition".
 *
 * The Initial Developer of the Original Code is Cognizo Technologies, Inc.
 * Portions created by the Initial Developer are Copyright (C) 2005 - 2006
 * (or from the year in which this file was created to the year 2006) by
 * Cognizo Technologies, Inc. All Rights Reserved.
 *
 *
 * This example module is meant as a very BASIC guide to the CATS module API.
 * It does not demonstrate every feature, but it should help you get started.
 * This example is also intended for programmers with a working knowledge of
 * PHP, so only aspects of the code specific to the CATS module API are
 * explained. Feel free to ask any questions you might have on the CATS Forums.
 *
 * This module adds a tab called Management to the tab bar, which simply outputs
 * "Management <your name>!".
 *
 *
 * $Id: ManagementUI.php 78 2007-01-17 07:38:53Z will $
 */

include_once('./lib/StringUtility.php');
include_once('./lib/DateUtility.php'); /* Depends on StringUtility. */
include_once('./lib/ResultSetUtility.php');
include_once('./lib/Companies.php');
include_once('./lib/Contacts.php');
include_once('./lib/JobOrders.php');
include_once('./lib/Attachments.php');
include_once('./lib/Export.php');
include_once('./lib/ListEditor.php');
include_once('./lib/FileUtility.php');
include_once('./lib/SavedLists.php');
include_once('./lib/ExtraFields.php');

/* The module's class name must always have the same name as the file it is
 * contained in, and it must always end in UI. We recommend "ModuleNameUI",
 * (in camel-caps) for example, JobOrdersUI or CandidatesUI.
 */
class ManagementUI extends UserInterface
{
    /* The __construct() method MUST ALWAYS be present in your module. This is
     * a "magic" PHP method that is called automatically whenever the module is
     * initialized, as well as when the module is passed-by during the module
     * detection process.
     */
    public function __construct()
    {
        /* This line MUST ALWAYS be present in your module's constructor.
         * This allows the CATS Module API to perform its own internal
         * initialization whenever your module is initialized or passed-by.
         */
        parent::__construct();
        $this->_realAccessLevel = $_SESSION['CATS']->getRealAccessLevel();
        $this->_authenticationRequired = true;
        $this->_moduleDirectory = 'management';
        $this->_moduleName = 'management';
        $this->_moduleTabText = 'Management';
        $this->_subTabs = array();
    }


    /* $this->handleRequest() is called whenever a URL is visited that
     * contains m=management. This method MUST ALWAYS be present in your module!
     */
    public function handleRequest()
    {
        if ($this->_realAccessLevel < ACCESS_LEVEL_SA)
        {
            CommonErrors::fatal(COMMONERROR_PERMISSION, $this);
            return;
        }

        $action = $this->getAction();

        /* Determine the action that was specified. The 'default' action is
         * triggered whenever a module is visited without an action.
         */
        switch ($action)
        {
            case 'showUser':
                $this->activityList();
                break;
            default:
                $this->usersList();
                break;
        }
    }

    /* This method is called by $this->handleRequest() when the module's tab is
     * visited, or when /index.php?m=management&a=management is loaded.
     */
    private function usersList()
    {
        $dataGrid = DataGrid::get("management:ManagementDataGrid", array());
        $this->_template->assign('active', $this);
        $this->_template->assign('dataGrid', $dataGrid);
        $this->_template->assign('userID', $_SESSION['CATS']->getUserID());

        if (!eval(Hooks::get('LISTS_LIST_BY_VIEW'))) return;
        $this->_template->display('./modules/management/usersList.tpl');
    }

    /* This method is called by $this->handleRequest() when the module's tab is
     * visited, or when /index.php?m=management&a=management is loaded.
     */
    private function activityList()
    {
        $dataGrid = DataGrid::get("management:ShowUserDataGrid", array());
        $this->_template->assign('active', $this);
        $this->_template->assign('dataGrid', $dataGrid);
        $this->_template->assign('userID', $_SESSION['CATS']->getUserID());

        if (!eval(Hooks::get('LISTS_LIST_BY_VIEW'))) return;
        $this->_template->display('./modules/management/activityList.tpl');
    }
}

?>
