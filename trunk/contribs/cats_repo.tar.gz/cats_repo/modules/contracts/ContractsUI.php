<?php
/*
 * CATS
 * Hello World Module (Sample)
 *
 * Copyright (C) 2005 - 2007 Cognizo Technologies, Inc.
 *
 *
 */

include_once('./lib/Article.php');
include_once('./lib/Companies.php');
include_once('./lib/Candidates.php');
include_once('./lib/CommonErrors.php');
include_once('./lib/Contracts.php');
include_once('./lib/ContractTemplates.php');
include_once('./lib/JobOrders.php');


class ContractsUI extends UserInterface
{
    /* The __construct() method MUST ALWAYS be present in your module. This is
     * a "magic" PHP method that is called automatically whenever the module is
     * initialized, as well as when the module is passed-by during the module
     * detection process.
     */
    public function __construct()
    {
        /* This line MUST ALWAYS be present in your module's constructor.
         * This allows the CATS Module API to perform its own internal
         * initialization whenever your module is initialized or passed-by.
         */
        parent::__construct();

        /* If this is set to true, the user will be required to be logged in
         * to use the module.
         *
         * For example, the Candidates module (and all of the other modules
         * that provide tabs) require login. If your module is going to expose
         * web pages to the public without login, you can change this setting.
         */
        $this->_authenticationRequired = true;

        /* This is the directory within modules/ that this module is contained
         * in. This should be the same as $this->_moduleName.
         */
        $this->_moduleDirectory = 'contracts';

        /* The lowercase module name of the module (used for m=modulename in
         * URLs, etc.). This should be the same as $this->_moduleDirectory.
         */
        $this->_moduleName = 'contracts';

        /* This is the text displayed on the module's tab. Set this to '' for
         * a module without a tab.
         */
        $this->_moduleTabText = 'Contracts';

        /* An array of sub-tab names and URLs for any sub-tabs your module
         * will provide. See the Clients module for an example.
         */
        $this->_subTabs = array(
        	'List Contracts'     => CATSUtility::getIndexName() . '?m=contracts',
        	'Add Contract'     => CATSUtility::getIndexName() . '?m=contracts&a=add',
        	'List Templates'     => CATSUtility::getIndexName() . '?m=contracts&a=template',
        	'Add Templates'     => CATSUtility::getIndexName() . '?m=contracts&a=addTemplate',
        	'List Articles'     => CATSUtility::getIndexName() . '?m=contracts&a=article',
        	'Add Article'     => CATSUtility::getIndexName() . '?m=contracts&a=addArticle'
        );
    }


    /* $this->handleRequest() is called whenever a URL is visited that
     * contains m=hello. This method MUST ALWAYS be present in your module!
     */
    public function handleRequest()
    {
        /* The UserInterface::getAction() method returns the action specified
         * in the URL (...&a=myAction). Never access $_GET['a'] manually.
         */
        $action = $this->getAction();

        /* Determine the action that was specified. The 'default' action is
         * triggered whenever a module is visited without an action.
         */
        switch ($action)
        {
            case 'add':
            	if ($this->isPostBack())
                {
                    $this->onAdd();
                }
                else
                {
                    $this->add();
                }
                break;
            case 'edit':
            	if ($this->isPostBack())
                {
                    $this->onEdit();
                }
                else
                {
                    $this->edit();
                }
                break;
            case 'show':
            	$this->show();
            	break;
            case 'export':
            	$this->export();
            	break;
            case 'exportjob':
            	$this->exportJob();
            	break;
            case 'select':
            	$this->select();
            	break;
            case 'delete':
            	$this->onDelete();
            	break;
            case 'article':
            	if ($this->isPostBack())
                {
                    $this->onArticle();
                }
                else
                {
                    $this->article();
                }
                break;
            case 'addArticle':
            	if ($this->isPostBack())
                {
                    $this->onAddArticle();
                }
                else
                {
                    $this->addArticle();
                }
                break;
            case 'editArticle':
            	if ($this->isPostBack())
                {
                    $this->onEditArticle();
                }
                else
                {
                    $this->editArticle();
                }
                break;
            case 'deleteArticle':
            	$this->onDeleteArticle();
            	break;           
            case 'showArticle':
            	$this->showArticle();
            	break;
            case 'template':
            	if ($this->isPostBack())
                {
                    $this->onTemplate();
                }
                else
                {
                    $this->template();
                }
                break;
            case 'addTemplate':
            	if ($this->isPostBack())
                {
                    $this->onAddTemplate();
                }
                else
                {
                    $this->addTemplate();
                }
                break;
            case 'editTemplate':
            	if ($this->isPostBack())
                {
                    $this->onEditTemplate();
                }
                else
                {
                    $this->editTemplate();
                }
                break;      
            case 'useTemplate':
            	if ($this->isPostBack())
                {
                    $this->onUseTemplate();
                }
                else
                {
                    $this->useTemplate();
                }
                break;  
            case 'showTemplate':
            	$this->showTemplate();
            	break;
            default:
                if ($this->isPostBack())
                {
                    $this->onShowContract();
                }
                else
                {
                    $this->showContract();
                }
                break;
        }
    }

    private function onAdd() 
    {
    	$contractID = $_GET['contractID'];
    	$number		= $this->getTrimmedInput('sequence', $_POST);
    	$companyID	= $this->getTrimmedInput('companyID', $_POST);
    	$contactID	= $this->getTrimmedInput('contactID', $_POST);
    	$notice		= $this->getTrimmedInput('notice', $_POST);
    	$honoraria	= $this->getTrimmedInput('honoraria', $_POST);
    	$discription= $this->getTrimmedInput('discription', $_POST);
    	$date		= $this->getTrimmedInput('date', $_POST);
    	$car		= $this->getTrimmedInput('car', $_POST);
    	$carprice	= $this->getTrimmedInput('carprice', $_POST);
    	$duration	= $this->getTrimmedInput('duration', $_POST);
    	$reference	= $this->getTrimmedInput('reference', $_POST);
    	
		if ($car == true)
		{
			$car = 1;
		}
    	
    	$contract = new Contract($this->_siteID);
    	$contractID = $contract->add($reference,$companyID,$contactID,$duration,$car,$carprice,$notice,$honoraria,$discription);
    	    	
    	for ($i = 1; $i <= $number; $i++)
		{
			$name = 'article'.$i;
			$articleID = $this->getTrimmedInput($name, $_POST);
			$contract->addArticle($contractID,$articleID,$i);
		}    	
		
		CATSUtility::transferRelativeURI(
            'm=contracts&a=show&contractID=' . $contractID
        );   	  	
    }
    
    private function add() 
    {
    	$companies = new Companies($this->_siteID);
        $selectedCompanyID = $companies->getDefaultCompany();

        /* Do we have a selected_company_id? */
        if ($selectedCompanyID === false)
        {
            $selectedCompanyContacts = array();
            $selectedCompanyLocation = array();
            $selectedDepartmentsString = '';

            $defaultCompanyID = $companies->getDefaultCompany();
            if ($defaultCompanyID !== false)
            {
                $defaultCompanyRS = $companies->get($defaultCompanyID);
            }
            else
            {
                $defaultCompanyRS = array();
            }

            $companyRS = array();
        }
        else
        {
            $selectedCompanyContacts = $companies->getContactsArray(
                $selectedCompanyID
            );
            $selectedCompanyLocation = $companies->getLocationArray(
                $selectedCompanyID
            );
            $departmentsRS = $companies->getDepartments($selectedCompanyID);
            $selectedDepartmentsString = ListEditor::getStringFromList(
                $departmentsRS, 'name'
            );

            $defaultCompanyID = false;
            $defaultCompanyRS = array();

            $companyRS = $companies->get($selectedCompanyID);
        } 
		      
        $article = new Article($this->_siteID);
        $articles = $article->getAll();
        
        $this->_template->assign('articles',$articles);
        $this->_template->assign('defaultCompanyID', $defaultCompanyID);
        $this->_template->assign('selectedCompanyID', $selectedCompanyID);
        $this->_template->assign('companyRS', $companyRS);
        $this->_template->assign('sessionCookie', $_SESSION['CATS']->getCookie());
        $this->_template->assign('selectedCompanyContacts', $selectedCompanyContacts);
    	$this->_template->assign('active', $this);
    	$this->_template->display('./modules/contracts/Add.tpl');
    }
    
    private function onEdit()
    {
    	$contractID = $_GET['contractID'];
    	
    	$number		= $this->getTrimmedInput('sequence', $_POST);
    	$companyID	= $this->getTrimmedInput('companyID', $_POST);
    	$contactID	= $this->getTrimmedInput('contactID', $_POST);
    	$notice		= $this->getTrimmedInput('notice', $_POST);
    	$honoraria	= $this->getTrimmedInput('honoraria', $_POST);
    	$discription= $this->getTrimmedInput('discription', $_POST);
    	$date		= $this->getTrimmedInput('date', $_POST);
    	$car		= $this->getTrimmedInput('car', $_POST);
    	$carprice	= $this->getTrimmedInput('carprice', $_POST);
    	$duration	= $this->getTrimmedInput('duration', $_POST);
    	$reference	= $this->getTrimmedInput('reference', $_POST);
    	
		if ($car == true)
		{
			$car = 1;
		}
    	
    	$contract = new Contract($this->_siteID);
    	$contract->update($contractID,$reference,$companyID,$contactID,$duration,$car,$carprice,$notice,$honoraria,$discription);
    	
    	$count = sizeof($contract->getArticles($contractID));
    	    	
    	for ($i = 1; $i <= $number; $i++)
		{
			$name = 'article'.$i;
			$articleID = $this->getTrimmedInput($name, $_POST);
			$oldArticleID = $contract->checkArticle($contractID,$i);
			if (($oldArticleID == NULL) OR ($count < $i))
			{
				$contract->addArticle($contractID,$articleID,$i);
			}
			else
			{
				if ($articleID !== $oldArticleID)
				{
					$contract->updateArticle($contractID,$i,$articleID);
				}
			}	
		}    	
		
		CATSUtility::transferRelativeURI(
            'm=contracts&a=show&contractID=' . $contractID
        );
    }
    
    private function edit()
    {
    	$contractID = $_GET['contractID'];

        $contracts = new Contract($this->_siteID);
        $data = $contracts->get($contractID);
        $selectedArticles = $contracts->getArticles($contractID);

        /* Bail out if we got an empty result set. */
        if (empty($data))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'The specified job order ID could not be found.');
        }
        
    	$companies = new Companies($this->_siteID);
        $selectedCompanyID = $companies->get($data['companyID']);

        $selectedCompanyContacts = $companies->getContactsArray($selectedCompanyID['companyID']);
        $defaultCompanyID = false;

        $companyRS = $companies->get($data['companyID']);

        $article = new Article($this->_siteID);
        $articles = $article->getAll();
        
        $this->_template->assign('articles',$articles);
        $this->_template->assign('data',$data);
        $this->_template->assign('contractID', $contractID);
        $this->_template->assign('defaultCompanyID', $defaultCompanyID);
        $this->_template->assign('selectedCompanyID', $selectedCompanyID);
        $this->_template->assign('selectedArticles', $selectedArticles);
        $this->_template->assign('companyRS', $companyRS);
        $this->_template->assign('sessionCookie', $_SESSION['CATS']->getCookie());
        $this->_template->assign('contactsRS', $selectedCompanyContacts);
    	$this->_template->assign('active', $this);
    	$this->_template->display('./modules/contracts/Edit.tpl');
    }
    
    private function show()
 	{
 		$contractID = $_GET['contractID'];

        $contracts = new Contract($this->_siteID);
        $data = $contracts->get($contractID);
        $localarticles = $contracts->getArticles($contractID);
        
        $article = new Article($this->_siteID);
        $articles = Array();
        
        for ($i = 0; $i < sizeof($localarticles); $i++)
        {
        	array_push($articles,$article->get($localarticles[$i]['articleID']));
        }

		$company = new Companies($this->_siteID);
		$localcompany = $company->get($data['companyID']);

		$contact = new Contacts($this->_siteID);
		$localcontact = $contact->get($data['contactID']);

        /* Bail out if we got an empty result set. */
        if (empty($data))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'The specified job order ID could not be found.');
        }
 		
 		$this->_template->assign('active', $this);
 		$this->_template->assign('company', $localcompany);
 		$this->_template->assign('contact', $localcontact);
 		$this->_template->assign('contractID', $contractID);
 		$this->_template->assign('data', $data);
 		$this->_template->assign('articles', $articles);
 		
    	$this->_template->display('./modules/contracts/show.tpl'); 		
 	}
 	
 	private function export()
 	{
 		$contractID = $_GET['contractID'];

        $contracts = new Contract($this->_siteID);
        $data = $contracts->get($contractID);
        $localarticles = $contracts->getArticles($contractID);
        
        $article = new Article($this->_siteID);
        $articles = Array();
        
        for ($i = 0; $i < sizeof($localarticles); $i++)
        {
        	array_push($articles,$article->get($localarticles[$i]['articleID']));
        }

		$company = new Companies($this->_siteID);
		$localcompany = $company->get($data['companyID']);

		$contact = new Contacts($this->_siteID);
		$localcontact = $contact->get($data['contactID']);
		
		$header = "";
		
		$myCompany = $company->get(1);
		
		$header = $myCompany['name']."\n";
		$header .= $myCompany['address']."\n";
		$header .= $myCompany['zip']." ".strtoupper($myCompany['city'])."\n";
		$header .= $myCompany['phone1'];
		
		//Create PDF
				
		$pdf = new PDF();
		
		//pdf settings
		$title = $data['reference'];
		$pdf->SetTitle($title);
		$pdf->SetSubject($data['reference']);
 		$pdf->SetAuthor($myCompany['name']);
 		$pdf->SetCreator($myCompany['name']);
 		//$pdf->SetMargins(30,35,30);
 		$pdf->SetAutoPageBreak(true,30);
 		$pdf->AcceptPageBreak(true);
 		$companyLogo = "/var/vhosts/careers.internal.k-net.be/htdocs/images/MyCompany.jpg";
 		$draft = false;
 		$pdf->MyHeader($header,$draft,$companyLogo);
 		$pdf->MyFooter("Human Resources Contract: ".$data['reference']);
 		
 		//Front Page
 		$pdf->AddPage();
 		$pdf->SetX(30);
	    $pdf->SetFont('Arial','',24);
	    $pdf->Cell(0,10,"CONTRACT",0,1,'L',0);
 		$pdf->Ln(12);
	    
	    $lines = "";
	    for ($i = 0; $i < sizeof($localarticles); $i++)
        {
        	$currentArticle = $article->get($localarticles[$i]['articleID']);
        	$lines .= "Artikel ".$contracts->getArticleNumber($contractID,$currentArticle['articleID']);
        	$lines .= ". ".strtoupper($currentArticle['title'])."\n";
        }
	    $pdf->SetFont('Arial','B',12);
	    $pdf->MultiCell(0,10,$lines,0,1,'J',0);
		$pdf->SetFont('Arial','',12);
 		$pdf->AddPage();
 		//Company-intro
 		$intro = "Bij onderhavige overeenkomst vertrouwt: ";
 		$pdf->SetX(30);
 		$pdf->Write(5,$intro);
 		$pdf->Ln(10);
 		
 		$pdf->SetLeftMargin(80);
 		 		
 		$companyInfo = $localcompany['name']."\n";
		$companyInfo .= $localcompany['address']."\n";
		$companyInfo .= $localcompany['zip']." ".strtoupper($localcompany['city']);
 		
 		$pdf->Write(4,$companyInfo);
 		$pdf->Ln(10);
 		 		
 		//MyCompany-intro
 		
 		$myIntro = '- hierna de "opdrachtgever" genoemd - aan:';

 		$pdf->SetX(30);
 		$pdf->Write(5,$myIntro);
 		$pdf->Ln(10);
 		
 		$pdf->SetX(80);
 		$myCompanyInfo = $myCompany['name']."\n";
		$myCompanyInfo .= $myCompany['address']."\n";
		$myCompanyInfo .= $myCompany['zip']." ".strtoupper($myCompany['city']);
		$pdf->Write(4,$myCompanyInfo);
		$pdf->SetLeftMargin(30);
 		$content = "";
		for ($i = 0; $i < sizeof($localarticles); $i++)
        {
        	$currentArticle = $article->get($localarticles[$i]['articleID']);
        	//Replace Fields with value
        	$discription = $currentArticle['discription'];
        	$count = substr_count($discription,'[INSERT_FIELD_');
        	
        	if ($count > 0)
        	{
        		for ($c = 0; $c < $count; $c++)
        		{
	        		$startcmd = substr($discription,strpos($discription,'[INSERT_FIELD'));
	        		$endcmd = substr($startcmd,0,strpos($startcmd,']'));
	        		$cmd = substr($endcmd,14);
	        		
	        		system("echo ".$cmd." >> /tmp/raf.out");
	        		
	        		if ($cmd == "car")
	        		{
	        			$carText = 'Indien het ter beschikking stellen van een <strong>bedrijfswagen</strong>, waarvan privé-gebruik toegestaan is, wordt als een <strong>bruto maandequivalent van '.$data['car_price'].' [EURO]</strong> in rekening gebracht. ';
	        			
	        			if ($data['car'] == true)
	        			{
	        				$newContent = $carText;
	        			}
	        			else
	        			{
	        				$newContent = '';
	        			}
	        		}
	        		elseif ($cmd == "contact")
	        		{
	        			$newContent = $localcontact['firstName'].' '.$localcontact['lastName'].' : '.$localcontact['title'];
	        		}
	        		elseif ($cmd == "date")
	        		{
	        			$newContent = date("d/m/Y");
	        		}
	        		elseif ($cmd == "salary")
	        		{
	        			$newContent = '';
	        		}
	        		else 
	        		{
	        			$newContent = $data[$cmd];
	        		}
	        		$discription = str_replace('[INSERT_FIELD_'.$cmd.']',$newContent,$discription);
        		}
        	}
        	$discription = mb_convert_encoding($discription, "ISO-8859-15", "UTF-8");
        	$discription = str_replace('[EURO]',chr(128),$discription);
        	$title = "Artikel ".$contracts->getArticleNumber($contractID,$currentArticle['articleID']).". ".strtoupper($currentArticle['title']);
        	$pdf->PrintChapter($title,$discription);
        }
        
        $pdf->Ln(5);

		$end = "Opgemaakt in twee originele exemplaren op: ".date("d/m/Y")."\n";
		$end .= "\n";		
		$end .= "Elk der partijen erkent door haar handtekening één origineel exemplaar te hebben ontvangen.\n";
		$end .= "\n";
		$end .= "\n";
		$end .= "\n";
		$end .= "\n";
        $end .="De opdrachtgever:\n";
        
        $end = mb_convert_encoding($end, "ISO-8859-15", "UTF-8");
        
 		$pdf->MultiCell(0,6,$end,0,1,'J',0);
        
        $pdf->Ln(15);
        
        $Y = $pdf->GetY();
        
        $companyInfo = $localcompany['name']."\n";
		$companyInfo .= $localcompany['address']."\n";
		$companyInfo .= $localcompany['zip']." ".strtoupper($localcompany['city'])."\n";
		$extraFieldRS = $company->extraFields->getValuesForShow($localcompany['companyID']);
		
		for ($i = 0; $i < count($extraFieldRS); $i++)
		{
			if ($extraFieldRS[$i]['fieldName'] == "BTW")
			{	
				$btw = $extraFieldRS[$i]['value'];
			}
		}
 		$companyInfo .= "BTW : ".$btw;
 		
 		
 		$pdf->MultiCell(0,6,$companyInfo,0,1,'L',0);
 		
 		$pdf->Ln(20);
 		
 		$pdf->Write(5,"Handtekening");
 		
 		$pdf->SetY($Y);
 		$pdf->SetLeftMargin(130);
 		
 		$myCompanyInfo = $myCompany['name']."\n";
		$myCompanyInfo .= $myCompany['address']."\n";
		$myCompanyInfo .= $myCompany['zip']." ".strtoupper($myCompany['city'])."\n";
		$extraFieldRS = $company->extraFields->getValuesForShow(1);
		
		for ($i = 0; $i < count($extraFieldRS); $i++)
		{
			if ($extraFieldRS[$i]['fieldName'] == "BTW")
			{	
				$btw = $extraFieldRS[$i]['value'];
			}
		}
		$myCompanyInfo .= "BTW : ".$btw;
		$pdf->MultiCell(0,6,$myCompanyInfo,0,1,'L',0);
		
 		$pdf->Ln(20);
 		
 		$pdf->Write(5,"Handtekening");
 		
 		header('Content-type: application/pdf');
 		//header('Content-Disposition: inline; filename="'.$data['reference'].'.pdf"');
        
		$pdf->Output($data['reference'].'.pdf','I');
 	}
    
    private function exportJob()
    {
    	$jobOrderID = $_GET['jobOrderID'];
    	
    	$countSelected = $this->getTrimmedInput('count', $_POST);
    	
    	$contracts 	= new Contract($this->_siteID);
    	$minCon 	= $contracts->getContract($jobOrderID);
    	$contract 	= $contracts->get($minCon['contractID']);
    	
    	$jobOrders 	= new JobOrders($this->_siteID);
    	$jobOrder 	= $jobOrders->get($jobOrderID);
    	
    	$sequence	= $contracts->getJobOrderNumber($minCon['contractID'],$jobOrderID);	           
        
        $localarticles = $contracts->getArticles($minCon['contractID']);
        
        $article = new Article($this->_siteID);
        $articles = Array();
        
        for ($i = 0; $i < sizeof($localarticles); $i++)
        {
        	array_push($articles,$article->get($localarticles[$i]['articleID']));
        }

		$company = new Companies($this->_siteID);
		$localcompany = $company->get($contract['companyID']);

		$contact = new Contacts($this->_siteID);
		$localcontact = $contact->get($contract['contactID']);
		
		$header = "";
		
		$myCompany = $company->get(1);
		
		$header = $myCompany['name']."\n";
		$header .= $myCompany['address']."\n";
		$header .= $myCompany['zip']." ".strtoupper($myCompany['city'])."\n";
		$header .= $myCompany['phone1'];
    	
    	//Create PDF
				
		$pdf = new PDF();
		
		$pdf->Open();
		
		//pdf settings
		$pdf->SetTitle($contract['reference']);
		$pdf->SetSubject($contract['reference']);
 		$pdf->SetAuthor($myCompany['name']);
 		$pdf->SetCreator($myCompany['name']);
 		$pdf->SetMargins(30,25,30);
 		$pdf->SetAutoPageBreak(true,30);
 		$pdf->AcceptPageBreak(true);
 		$companyLogo = "/var/vhosts/cats.internal.k-search.be/htdocs/images/MyCompany.jpg";
 		$draft = false;
 		$pdf->MyHeader($header,$draft,$companyLogo);
 		$footer = "WERKOPDRACHT ".$sequence." : ".$contract['reference'];
 		$pdf->MyFooter($footer);
 		
		
 		$pdf->AddPage();
 		
 		$pdf->SetX(20);
 		$pdf->SetFont('Arial','B',12);
 		$line = "WERKOPDRACHT ".$sequence." : ".$jobOrder['title'];
 		$pdf->Write(5,$line);
 		
 		$pdf->Ln(10);
 		
 		$pdf->SetFont('Arial','',12);
 		$line = "Deze werkopdracht hoort bij het Human Resources Contract ";
 		$pdf->Write(5,$line);
 		
 		$pdf->Ln(15);
 		
 		$pdf->SetFont('Arial','B',12);
 		$pdf->Cell(0,5,$contract['reference'],0,1,'C',0);
 		
 		$pdf->Ln(10);
 		
 		$line = "De volgende bepalingen hebben voorrang op het contract.";
 		$pdf->Write(5,$line);
 		
 		$pdf->Ln(10);
 		
 		$pdf->SetFont('Arial','',12);
 		$line = "Toevertrouwde recruteringsopdracht :";
 		$pdf->Write(5,$line);
 		
 		$pdf->Ln(10);
 		
 		$line = "Job Title : <strong>".$jobOrder['title']."</strong>";
 		$pdf->WriteHTML($line);
 		
 		$pdf->Ln(10);
 		
 		$pdf->SetLeftMargin(40);
 		
 		//$pdf->Cell(0,6,$jobOrder['description'],0,1,'L',0);
 		
 		$pdf->WriteHTML($jobOrder['description']);
 		
 		$pdf->SetLeftMargin(30);
 		
 		$pdf->Ln(10);
 		
 		$line = "Datum : ".date("d F Y");
 		$pdf->Write(5,$line); 		

 		$pdf->Ln(10);
 		
 		$printArticles = Array();
 		for ($j = 0; $j < $countSelected; $j++)
	    	{
	    		$tmp 	= 	$this->getTrimmedInput('article'.$j, $_POST);
	    		if ($tmp == "true")
	    		{
	    			$printArticle = $this->getTrimmedInput('print'.$j, $_POST);
	    			array_push($printArticles,$printArticle);
	    		}
	    	}
 		
		for ($i = 0; $i < sizeof($localarticles); $i++)
        {
        	$currentArticle = $article->get($localarticles[$i]['articleID']);
        	$discription = $currentArticle['discription'];
        	$count = substr_count($discription,'[INSERT_FIELD_');
    	
    		if (in_array($localarticles[$i]['articleID'],$printArticles))
	    	{        	
	        	if ($count > 0)
	        	{
	        		for ($c = 0; $c < $count; $c++)
	        		{
		        		$startcmd = substr($discription,strpos($discription,'[INSERT_FIELD'));
		        		$endcmd = substr($startcmd,0,strpos($startcmd,']'));
		        		$cmd = substr($endcmd,14);
		        		
		        		system("echo $cmd >> /tmp/raf.out");
		        		
		        		if ($cmd == "car")
		        		{
		        			$carText = 'Indien het ter beschikking stellen van een bedrijfswagen, waarvan privé-gebruik toegestaan is, wordt als een bruto maandequivalent van '.$contract['car_price'].' [EURO] in rekening gebracht. ';
		        			
		        			if ($contract['car'] == true)
		        			{
		        				$discription = str_replace('[INSERT_FIELD_'.$cmd.']',$carText,$discription);
		        			}
		        			else
		        			{
		        				$discription = str_replace('[INSERT_FIELD_'.$cmd.']','',$discription);
		        			}
		        		}
		        		elseif ($cmd == "salary")
		        		{
		        			$salaryText = 'Het verwacht bruto maandsalaris wordt geschat op '.$jobOrder['salary'].' [EURO].';
		        			
		        			$discription = substr($discription,0,strpos($discription,'[INSERT_FIELD'));
							$discription .= $salaryText;
							$c = $count;
		        		}
		        		elseif ($cmd == "contact")
		        		{
		        			$newContent = $localcontact['firstName'].' '.$localcontact['lastName'].' : '.$localcontact['title'];
		        			$discription = str_replace('[INSERT_FIELD_'.$cmd.']',$newContent,$discription);
		        		}
		        		elseif ($cmd == "date")
		        		{
		        			$discription = str_replace('[INSERT_FIELD_'.$cmd.']',date("d/m/Y"),$discription);
		        		}
		        		else 
		        		{
		        			$discription = str_replace('[INSERT_FIELD_'.$cmd.']',$contract[$cmd],$discription);
		        		}
	        		}
	        	}
	        	$discription = mb_convert_encoding($discription, "ISO-8859-15", "UTF-8");
	        	$discription = str_replace('[EURO]',chr(128),$discription);
	        	$title = trim(strtoupper($currentArticle['title']));
	        	$pdf->PrintChapter($title,$discription);
	    	}
        }
        
        $pdf->Ln(5);

		$end = "Opgemaakt in twee originele exemplaren op: ".date("d/m/Y")."\n";
		$end .= "\n";		
		$end .= "Elk der partijen erkent door haar handtekening één origineel exemplaar te hebben ontvangen.\n";
		$end .= "\n";
		$end .= "\n";
		$end .= "\n";
		$end .= "\n";
        $end .="De opdrachtgever:\n";
        
        $end = mb_convert_encoding($end, "ISO-8859-15", "UTF-8");
        
 		$pdf->MultiCell(0,6,$end,0,1,'L',0);
        
        $pdf->Ln(15);
        
        $Y = $pdf->GetY();
        
        $companyInfo = $localcompany['name']."\n";
		$companyInfo .= $localcompany['address']."\n";
		$companyInfo .= $localcompany['zip']." ".strtoupper($localcompany['city'])."\n";
		$extraFieldRS = $company->extraFields->getValuesForShow($localcompany['companyID']);
		
		for ($i = 0; $i < count($extraFieldRS); $i++)
		{
			if ($extraFieldRS[$i]['fieldName'] == "BTW")
			{	
				$btw = $extraFieldRS[$i]['value'];
			}
		}
 		$companyInfo .= "BTW : ".$btw;
 		
 		
 		$pdf->MultiCell(0,6,$companyInfo,0,1,'L',0);
 		
 		$pdf->Ln(20);
 		
 		$pdf->Write(5,"Handtekening");
 		
 		$pdf->SetY($Y);
 		$pdf->SetLeftMargin(130);
 		
 		$myCompanyInfo = $myCompany['name']."\n";
		$myCompanyInfo .= $myCompany['address']."\n";
		$myCompanyInfo .= $myCompany['zip']." ".strtoupper($myCompany['city'])."\n";
		$extraFieldRS = $company->extraFields->getValuesForShow(1);
		
		for ($i = 0; $i < count($extraFieldRS); $i++)
		{
			if ($extraFieldRS[$i]['fieldName'] == "BTW")
			{	
				$btw = $extraFieldRS[$i]['value'];
			}
		}
		$myCompanyInfo .= "BTW : ".$btw;
		$pdf->MultiCell(0,6,$myCompanyInfo,0,1,'L',0);
		
 		$pdf->Ln(20);
 		
 		$pdf->Write(5,"Handtekening");
 		
 		
 		header('Content-type: application/pdf');
 		header('Content-Disposition: inline; filename="'.$footer.'.pdf"');
        
		$pdf->Output($footer.'.pdf','I');
    }
    
    private function select()
    {
    	$jobOrderID = $_GET['jobOrderID'];
    	
    	$contracts 	= new Contract($this->_siteID);
    	$minCon 	= $contracts->getContract($jobOrderID);
    	$contract 	= $contracts->get($minCon['contractID']);
    	
    	$jobOrders 	= new JobOrders($this->_siteID);
    	$jobOrder 	= $jobOrders->get($jobOrderID);
    	
    	$sequence	= $contracts->getJobOrderNumber($minCon['contractID'],$jobOrderID);	           
        
        $localarticles = $contracts->getArticles($minCon['contractID']);
        
        $article = new Article($this->_siteID);
        $articles = Array();
        
        for ($i = 0; $i < sizeof($localarticles); $i++)
        {
        	array_push($articles,$article->get($localarticles[$i]['articleID']));
        }
		
		$this->_template->assign('jobOrderID', $jobOrderID);
 		$this->_template->assign('articles', $articles);
 		$this->_template->assign('active', $this);
    	$this->_template->display('./modules/contracts/select.tpl'); 	

    }    
    
    private function onDelete()
    {
        if ($this->_accessLevel < ACCESS_LEVEL_DELETE)
        {
            CommonErrors::fatal(COMMONERROR_PERMISSION, $this, 'Invalid user level for action.');
        }

        /* Bail out if we don't have a valid job order ID. */
        if (!$this->isRequiredIDValid('contractID', $_GET))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'Invalid contract ID.');
        }

        $contractID = $_GET['contractID'];

        if (!eval(Hooks::get('JO_ON_DELETE_PRE'))) return;

        $contract = new Contract($this->_siteID);
        $contract->delete($contractID);

        if (!eval(Hooks::get('JO_ON_DELETE_POST'))) return;

        CATSUtility::transferRelativeURI('m=contracts');
    }

	private function onArticle() 
    {
    }

	private function article() 
    {
    	
    	$dataGridProperties = DataGrid::getRecentParamaters("contracts:ArticlesListByViewDataGrid");

        /* If this is the first time we visited the datagrid this session, the recent paramaters will
         * be empty.  Fill in some default values. */
        if ($dataGridProperties == array())
        {
            $dataGridProperties = array('rangeStart'    => 0,
                                        'maxResults'    => 15,
                                        'filterVisible' => false);
        }

        $dataGrid = DataGrid::get("contracts:ArticlesListByViewDataGrid", $dataGridProperties);

        $article = new Article($this->_siteID);
        $this->_template->assign('totalArticles', $article->getCount());

        $this->_template->assign('active', $this);
        $this->_template->assign('dataGrid', $dataGrid);

        if (!eval(Hooks::get('CANDIDATE_LIST_BY_VIEW'))) return;
        
    	$this->_template->display('./modules/contracts/Article.tpl');
    }
    
    private function onAddArticle() 
    {
    	$name       = $this->getTrimmedInput('name', $_POST);
        $title 		= $this->getTrimmedInput('title', $_POST);
        $discription = $this->getTrimmedInput('discription', $_POST);
        
        $article = new Article($this->_siteID);
        $articleID = $article->add(
            $name, $title, $discription
        );

        if ($articleID <= 0)
        {
            CommonErrors::fatal(COMMONERROR_RECORDERROR, $this, 'Failed to add job order.');
        }

        /* Update extra fields. */
        $article->extraFields->setValuesOnEdit($articleID);

        if (!eval(Hooks::get('JO_ON_ADD_POST'))) return;

        CATSUtility::transferRelativeURI(
            'm=contracts&a=showArticle&articleID=' . $articleID
        );
    }
    
    private function addArticle() 
    {
    	$this->_template->assign('active', $this);
    	$this->_template->display('./modules/contracts/AddArticle.tpl');
    }

    private function onEditArticle() 
    {
    	$articleID = $_GET['articleID'];
    	
    	$name       = $this->getTrimmedInput('name', $_POST);
        $title 		= $this->getTrimmedInput('title', $_POST);
        $discription = $this->getTrimmedInput('discription', $_POST);
        
        $article = new Article($this->_siteID);
        $articles = $article->update(
            $articleID, $name, $title, $discription
        );

        if ($articles <= 0)
        {
            CommonErrors::fatal(COMMONERROR_RECORDERROR, $this, 'Failed to save changes.');
        }

        if (!eval(Hooks::get('JO_ON_ADD_POST'))) return;

        CATSUtility::transferRelativeURI(
            'm=contracts&a=showArticle&articleID=' . $articleID
        );
    }
	
	private function editArticle() 
    {
    	$articleID = $_GET['articleID'];

        $articles = new Article($this->_siteID);
        $data = $articles->get($articleID);

        /* Bail out if we got an empty result set. */
        if (empty($data))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'The specified job order ID could not be found.');
        }
 		
 		$this->_template->assign('active', $this);
 		$this->_template->assign('articleID', $articleID);
 		$this->_template->assign('data', $data);
 		
    	$this->_template->display('./modules/contracts/editArticle.tpl');
    }
 	
 	private function onDeleteArticle()
    {
        if ($this->_accessLevel < ACCESS_LEVEL_DELETE)
        {
            CommonErrors::fatal(COMMONERROR_PERMISSION, $this, 'Invalid user level for action.');
        }

        /* Bail out if we don't have a valid job order ID. */
        if (!$this->isRequiredIDValid('articleID', $_GET))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'Invalid article ID.');
        }

        $articleID = $_GET['articleID'];

        if (!eval(Hooks::get('JO_ON_DELETE_PRE'))) return;

        $article = new Article($this->_siteID);
        $article->delete($articleID);

        if (!eval(Hooks::get('JO_ON_DELETE_POST'))) return;

        CATSUtility::transferRelativeURI('m=contracts&a=article');
    }	
        	
    private function showArticle()
 	{
 		$articleID = $_GET['articleID'];

        $articles = new Article($this->_siteID);
        $data = $articles->get($articleID);

        /* Bail out if we got an empty result set. */
        if (empty($data))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'The specified job order ID could not be found.');
        }
 		
 		$this->_template->assign('active', $this);
 		$this->_template->assign('articleID', $articleID);
 		$this->_template->assign('data', $data);
 		
    	$this->_template->display('./modules/contracts/showArticle.tpl'); 		
 	}

	private function onTemplate()
    {
    }

    private function template()
    {
        $dataGridProperties = DataGrid::getRecentParamaters("contracts:contractTemplatesListByViewDataGrid");

        /* If this is the first time we visited the datagrid this session, the recent paramaters will
         * be empty.  Fill in some default values. */
        if ($dataGridProperties == array())
        {
            $dataGridProperties = array('rangeStart'    => 0,
                                        'maxResults'    => 15,
                                        'filterVisible' => false);
        }

        $dataGrid = DataGrid::get("contracts:contractTemplatesListByViewDataGrid", $dataGridProperties);

        $contract = new ContractTemplates($this->_siteID);
        $this->_template->assign('totalTemplates', $contract->getCount());

        $this->_template->assign('active', $this);
        $this->_template->assign('dataGrid', $dataGrid);

        if (!eval(Hooks::get('CANDIDATE_LIST_BY_VIEW'))) return;
        
    	$this->_template->display('./modules/contracts/Templates.tpl');
    }

    private function onAddTemplate() 
    {
    	$number		= $this->getTrimmedInput('sequence', $_POST);
    	$companyID	= $this->getTrimmedInput('companyID', $_POST);
    	$contactID	= $this->getTrimmedInput('contactID', $_POST);
    	$notice		= $this->getTrimmedInput('notice', $_POST);
    	$honoraria	= $this->getTrimmedInput('honoraria', $_POST);
    	$discription= $this->getTrimmedInput('discription', $_POST);
    	$date		= $this->getTrimmedInput('date', $_POST);
    	$car		= $this->getTrimmedInput('car', $_POST);
    	$carprice	= $this->getTrimmedInput('carprice', $_POST);
    	$duration	= $this->getTrimmedInput('duration', $_POST);
    	$reference	= $this->getTrimmedInput('reference', $_POST);
    	
		if ($car == true)
		{
			$car = 1;
		}
    	
    	$contract = new ContractTemplates($this->_siteID);
    	$contractID = $contract->add($reference,$companyID,$contactID,$duration,$car,$carprice,$notice,$honoraria,$discription);
    	    	
    	for ($i = 1; $i <= $number; $i++)
		{
			$name = 'article'.$i;
			$articleID = $this->getTrimmedInput($name, $_POST);
			$contract->addArticle($contractID,$articleID,$i);
		}    	
		
		CATSUtility::transferRelativeURI(
            'm=contracts&a=showTemplate&contractID=' . $contractID
        );   	  	
    }
	
	private function addTemplate() 
    {
    	$companies = new Companies($this->_siteID);
        $selectedCompanyID = $companies->getDefaultCompany();

        /* Do we have a selected_company_id? */
        if ($selectedCompanyID === false)
        {
            $selectedCompanyContacts = array();
            $selectedCompanyLocation = array();
            $selectedDepartmentsString = '';

            $defaultCompanyID = $companies->getDefaultCompany();
            if ($defaultCompanyID !== false)
            {
                $defaultCompanyRS = $companies->get($defaultCompanyID);
            }
            else
            {
                $defaultCompanyRS = array();
            }

            $companyRS = array();
        }
        else
        {
            $selectedCompanyContacts = $companies->getContactsArray(
                $selectedCompanyID
            );
            $selectedCompanyLocation = $companies->getLocationArray(
                $selectedCompanyID
            );
            $departmentsRS = $companies->getDepartments($selectedCompanyID);
            $selectedDepartmentsString = ListEditor::getStringFromList(
                $departmentsRS, 'name'
            );

            $defaultCompanyID = false;
            $defaultCompanyRS = array();

            $companyRS = $companies->get($selectedCompanyID);
        } 
		      
        $article = new Article($this->_siteID);
        $articles = $article->getAll();
        
        $this->_template->assign('articles',$articles);
        $this->_template->assign('defaultCompanyID', $defaultCompanyID);
        $this->_template->assign('selectedCompanyID', $selectedCompanyID);
        $this->_template->assign('companyRS', $companyRS);
        $this->_template->assign('sessionCookie', $_SESSION['CATS']->getCookie());
        $this->_template->assign('selectedCompanyContacts', $selectedCompanyContacts);
    	$this->_template->assign('active', $this);
    	$this->_template->display('./modules/contracts/AddTemplate.tpl');
    }

	private function onEditTemplate()
 	{
 		$contractID = $_GET['contractID'];
    	
    	$number		= $this->getTrimmedInput('sequence', $_POST);
    	$companyID	= $this->getTrimmedInput('companyID', $_POST);
    	$contactID	= $this->getTrimmedInput('contactID', $_POST);
    	$notice		= $this->getTrimmedInput('notice', $_POST);
    	$honoraria	= $this->getTrimmedInput('honoraria', $_POST);
    	$discription= $this->getTrimmedInput('discription', $_POST);
    	$date		= $this->getTrimmedInput('date', $_POST);
    	$car		= $this->getTrimmedInput('car', $_POST);
    	$carprice	= $this->getTrimmedInput('carprice', $_POST);
    	$duration	= $this->getTrimmedInput('duration', $_POST);
    	$reference	= $this->getTrimmedInput('reference', $_POST);
    	
		if ($car == true)
		{
			$car = 1;
		}
    	
    	$contract = new ContractTemplates($this->_siteID);
    	$contract->update($contractID,$reference,$companyID,$contactID,$duration,$car,$carprice,$notice,$honoraria,$discription);
    	
    	$count = sizeof($contract->getArticles($contractID));
    	    	
    	for ($i = 1; $i <= $number; $i++)
		{
			$name = 'article'.$i;
			$articleID = $this->getTrimmedInput($name, $_POST);
			$oldArticleID = $contract->checkArticle($contractID,$i);
			if (($oldArticleID == NULL) OR ($count < $i))
			{
				$contract->addArticle($contractID,$articleID,$i);
			}
			else
			{
				if ($articleID !== $oldArticleID)
				{
					$contract->updateArticle($contractID,$i,$articleID);
				}
			}	
		}    	
		
		CATSUtility::transferRelativeURI(
            'm=contracts&a=showTemplate&contractID=' . $contractID
        );
 	}
 	
 	private function editTemplate()
 	{
 		$contractID = $_GET['contractID'];

        $contracts = new ContractTemplates($this->_siteID);
        $data = $contracts->get($contractID);
        $selectedArticles = $contracts->getArticles($contractID);

        /* Bail out if we got an empty result set. */
        if (empty($data))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'The specified job order ID could not be found.');
        }
        
    	$companies = new Companies($this->_siteID);
        $selectedCompanyID = $companies->get($data['companyID']);

        $selectedCompanyContacts = $companies->getContactsArray($selectedCompanyID['companyID']);
        $defaultCompanyID = false;

        $companyRS = $companies->get($data['companyID']);

        $article = new Article($this->_siteID);
        $articles = $article->getAll();
        
        $this->_template->assign('articles',$articles);
        $this->_template->assign('data',$data);
        $this->_template->assign('contractID', $contractID);
        $this->_template->assign('defaultCompanyID', $defaultCompanyID);
        $this->_template->assign('selectedCompanyID', $selectedCompanyID);
        $this->_template->assign('selectedArticles', $selectedArticles);
        $this->_template->assign('companyRS', $companyRS);
        $this->_template->assign('sessionCookie', $_SESSION['CATS']->getCookie());
        $this->_template->assign('contactsRS', $selectedCompanyContacts);
    	$this->_template->assign('active', $this);
    	$this->_template->display('./modules/contracts/EditTemplate.tpl');
 	}
 	
 	private function onUseTemplate()
 	{
 	}
 	
 	private function useTemplate()
 	{
 		$contractID = $_GET['contractID'];

        $contracts = new ContractTemplates($this->_siteID);
        $data = $contracts->get($contractID);
        $selectedArticles = $contracts->getArticles($contractID);

        /* Bail out if we got an empty result set. */
        if (empty($data))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'The specified contract ID could not be found.');
        }
        
    	$companies = new Companies($this->_siteID);
        $selectedCompanyID = $companies->get($data['companyID']);

        $selectedCompanyContacts = $companies->getContactsArray(
            $selectedCompanyID
        );
        $defaultCompanyID = false;
        $defaultCompanyRS = array();

        $companyRS = $companies->get($data['companyID']);

        $article = new Article($this->_siteID);
        $articles = $article->getAll();
        
        $this->_template->assign('articles',$articles);
        $this->_template->assign('data',$data);
        $this->_template->assign('contractID', $contractID);
        $this->_template->assign('defaultCompanyID', $defaultCompanyID);
        $this->_template->assign('selectedCompanyID', $selectedCompanyID);
        $this->_template->assign('selectedArticles', $selectedArticles);
        $this->_template->assign('companyRS', $companyRS);
        $this->_template->assign('sessionCookie', $_SESSION['CATS']->getCookie());
        $this->_template->assign('selectedCompanyContacts', $selectedCompanyContacts);
    	$this->_template->assign('active', $this);
    	$this->_template->display('./modules/contracts/Use.tpl');
 	}
 	
	private function showTemplate()
 	{
 		$contractID = $_GET['contractID'];

        $contracts = new ContractTemplates($this->_siteID);
        $data = $contracts->get($contractID);
        $localarticles = $contracts->getArticles($contractID);
        
        $article = new Article($this->_siteID);
        $articles = Array();
        
        for ($i = 0; $i < sizeof($localarticles); $i++)
        {
        	array_push($articles,$article->get($localarticles[$i]['articleID']));
        }

		$company = new Companies($this->_siteID);
		$localcompany = $company->get($data['companyID']);

		$contact = new Contacts($this->_siteID);
		$localcontact = $contact->get($data['contactID']);

        /* Bail out if we got an empty result set. */
        if (empty($data))
        {
            CommonErrors::fatal(COMMONERROR_BADINDEX, $this, 'The specified job order ID could not be found.');
        }
 		
 		$this->_template->assign('active', $this);
 		$this->_template->assign('company', $localcompany);
 		$this->_template->assign('contact', $localcontact);
 		$this->_template->assign('contractID', $contractID);
 		$this->_template->assign('data', $data);
 		$this->_template->assign('articles', $articles);
 		
    	$this->_template->display('./modules/contracts/showTemplates.tpl'); 		
 	}
	
	private function onShowContract()
    {
    }
	
    private function showContract()
    {
        $dataGridProperties = DataGrid::getRecentParamaters("contracts:contractsListByViewDataGrid");

        /* If this is the first time we visited the datagrid this session, the recent paramaters will
         * be empty.  Fill in some default values. */
        if ($dataGridProperties == array())
        {
            $dataGridProperties = array('rangeStart'    => 0,
                                        'maxResults'    => 15,
                                        'filterVisible' => false);
        }

        $dataGrid = DataGrid::get("contracts:contractsListByViewDataGrid", $dataGridProperties);

        $contract = new Contract($this->_siteID);
        $this->_template->assign('totalContracts', $contract->getCount());

        $this->_template->assign('active', $this);
        $this->_template->assign('dataGrid', $dataGrid);

        if (!eval(Hooks::get('CANDIDATE_LIST_BY_VIEW'))) return;
        
    	$this->_template->display('./modules/contracts/Contracts.tpl');
    }
}

?>
