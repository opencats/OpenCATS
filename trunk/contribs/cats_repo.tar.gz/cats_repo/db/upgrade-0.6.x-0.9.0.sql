INSERT INTO `access_level` (`access_level_id`, `short_description`, `long_description`) VALUES ('50', 'Sync', 'User for synchronization data with front-end site.');
