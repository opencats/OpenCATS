ALTER TABLE `user` DROP COLUMN `is_beta_tester`;

DROP TABLE `address_parser_failures`;
