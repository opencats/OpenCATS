INSERT INTO `cats`.`activity_type` (`activity_type_id`, `short_description`) VALUES ('1100', 'Call 1st'), ('1000', 'Call+contact later'), ('900', 'LinkedIn');
