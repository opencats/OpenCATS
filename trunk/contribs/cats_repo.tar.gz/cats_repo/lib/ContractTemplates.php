<?php
/**
 * CATS
 * Contracts Library
 *
 * Copyright (C) 2005 - 2007 Nijskens Raf.
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * @package    CATS
 * @subpackage Library
 * @copyright Copyright (C) 2005 - 2007 Nijskens Raf
 */


/**
 *  Contracts Library
 *  @package    CATS
 *  @subpackage Library
 */
class ContractTemplates
{
    private $_db;
    private $_siteID;

    public $extraFields;


    public function __construct($siteID)
    {
        $this->_siteID = $siteID;
        $this->_db = DatabaseConnection::getInstance();
        $this->extraFields = new ExtraFields($siteID, DATA_ITEM_COMPANY);
    }


    /**
     * Adds a company to the database and returns its company ID.
     *
     * @param string Name
     * @param string Address line
     * @param string City
     * @param string State
     * @param string Zip code
     * @param string Phone 1
     * @param string Phone 2
     * @param string Url
     * @param string Key technologies
     * @param boolean Is company hot
     * @param string Company notes
     * @param integer Entered-by user
     * @param integer Owner user
     * @return new Company ID, or -1 on failure.
     */
    public function add($reference,$companyID,$contactID,$duration,$car,$carprice,$notice,$honoraria,$discription)
    {
        $sql = sprintf(
            "INSERT INTO contract (
                ref,
                company_id,
                contact_id,
                duration,
                car,
                car_price,
                notice,
                honoraria,
                discription_salary,
                site_id,
                date_created,
                date_modified,
                template
            )
            VALUES (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                NOW(),
                NOW(),
                1
            )",
            $this->_db->makeQueryString($reference),
            $this->_db->makeQueryString($companyID),
            $this->_db->makeQueryString($contactID),
            $this->_db->makeQueryString($duration),
            $this->_db->makeQueryString($car),
            $this->_db->makeQueryString($carprice),
            $this->_db->makeQueryString($notice),
            $this->_db->makeQueryString($honoraria),
            $this->_db->makeQueryString($discription),
            $this->_siteID
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
    }

    /**
     * Updates a company.
     *
     * @param integer Company ID
     * @param string Name
     * @param string Address line
     * @param string City
     * @param string State
     * @param string Zip Code
     * @param string Phone 1
     * @param string Phone 2
     * @param string URL
     * @param string Key Technologies
     * @param boolean Is company hot
     * @param string Company notes
     * @param integer Owner user
     * @param integer Billing contact ID
     * @return boolean True if successful; false otherwise.
     */
    public function update($contractID,$reference,$companyID,$contactID,$duration,$car,$carprice,$notice,$honoraria,$discription)
    {
        $sql = sprintf(
            "UPDATE
                contract
             SET
                ref				= %s,
                company_id      = %s,
                contact_id      = %s,
                duration        = %s,
                car             = %s,
                car_price       = %s,
                notice          = %s,
                honoraria       = %s,
                discription_salary     = %s,
                date_modified   = NOW()
            WHERE
                contract_id = %s
            AND
                site_id = %s",
            $this->_db->makeQueryString($reference),
            $this->_db->makeQueryString($companyID),
            $this->_db->makeQueryString($contactID),
            $this->_db->makeQueryString($duration),
            $this->_db->makeQueryString($car),
            $this->_db->makeQueryString($carprice),
            $this->_db->makeQueryString($notice),
            $this->_db->makeQueryString($honoraria),
            $this->_db->makeQueryString($discription),
            $this->_db->makeQueryString($contractID),
            $this->_siteID
        );

        $preHistory = $this->get($contractID);
        $queryResult = $this->_db->query($sql);
        $postHistory = $this->get($contractID);

        if (!$queryResult)
        {
            return false;
        }

        $history = new History($this->_siteID);
        $history->storeHistoryChanges(DATA_ITEM_COMPANY, $contractID, $preHistory, $postHistory);

        return true;
    }

    /**
     * Removes a company and all associated records from the system.
     *
     * @param integer Company ID
     * @return void
     */
    public function delete($contractID)
    {
    	/* Delete the contract mappings. */
        $sql = sprintf(
            "DELETE FROM
                contract_article
            WHERE
                contract_id = %s
            AND
                site_id = %s",
            $contractID,
            $this->_siteID
        );
        
        /* Delete the company. */
        $sql = sprintf(
            "DELETE FROM
                contract
            WHERE
                contract_id = %s
            AND
                site_id = %s",
            $contractID,
            $this->_siteID
        );
        $this->_db->query($sql);

        $history = new History($this->_siteID);
        $history->storeHistoryDeleted(DATA_ITEM_COMPANY, $contractID);

        /* Delete from saved lists. */
        $sql = sprintf(
            "DELETE FROM
                saved_list_entry
            WHERE
                data_item_id = %s
            AND
                site_id = %s
            AND
                data_item_type = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_siteID,
            DATA_ITEM_COMPANY
        );
        $this->_db->query($sql);

        /* Delete extra fields. */
        $this->extraFields->deleteValueByDataItemID($contractID);
    }

    /**
     * Returns all relevent company information for a given company ID.
     *
     * @param integer Company ID
     * @return array Company data
     */
    public function get($contractID)
    {
        $sql = sprintf(
            "SELECT
                contract.company_id AS companyID,
                contract.ref AS reference,
                contract.car AS car,
                contract.car_price AS car_price,
                contract.notice AS notice,
                contract.honoraria AS honoraria,
                contract.duration AS duration,
                contract.discription_salary AS discription_salary,
                contract.company_id AS companyID,
                contract.contact_id AS contactID,
				DATE_FORMAT(
                    contract.date_modified, '%%m-%%d-%%y'
                ) AS dateModified,
                DATE_FORMAT(
                    contract.date_created, '%%m-%%d-%%y'
                ) AS dateCreated
            FROM
                contract
            LEFT JOIN contact
                ON contract.contact_id = contact.contact_id
            WHERE
                contract.contract_id = %s
            AND
                contract.template = 1
            AND
                contract.site_id = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_siteID
        );

        return $this->_db->getAssoc($sql);
    }
    
    public function getCount()
    {
        $sql = sprintf(
            "SELECT
                COUNT(*) AS totalContracts
            FROM
                contract
            WHERE
                contract.site_id = %s
            AND
                contract.template = 1",
            $this->_siteID
        );

        return $this->_db->getColumn($sql, 0, 0);
    }

	public function addArticle($contractID,$articleID,$sequence)
	{
		$sql = sprintf(
            "INSERT INTO contract_article (
                contract_id,
                article_id,
                article_number,
                site_id
            )
            VALUES (
                %s,
                %s,
                %s,
                %s
            )",
            $this->_db->makeQueryString($contractID),
            $this->_db->makeQueryString($articleID),
            $this->_db->makeQueryString($sequence),
            $this->_siteID
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
	}
	
	public function checkArticle($contractID,$sequence)
	{
		$sql = sprintf(
            "SELECT
                contract_article.article_id AS articleID
            FROM
                contract_article
            WHERE
                contract_article.contract_id = %s
            AND
                contract_article.site_id = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_siteID
        );
        
        $queryResult = $this->_db->getAssoc($sql);
        return $queryResult['articleID'];
	}
	
	public function updateArticle($contractID,$sequence,$articleID)
	{
		$sql = sprintf(
			"UPDATE
                contract_article
             SET
                article_id		= %s
             WHERE
                contract_article.contract_id = %s
             AND
                contract_article.site_id = %s
             AND
                contract_article.article_number = %s",

            $this->_db->makeQueryString($articleID),
            $this->_db->makeQueryString($contractID),
            $this->_siteID,
            $this->_db->makeQueryString($sequence)
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
	}
	
	public function getArticles($contractID)
	{
		$sql = sprintf(
            "SELECT
                contract_article.article_id AS articleID,
                contract_article.article_number AS sequence
            FROM
                contract_article
            WHERE
                contract_article.contract_id = %s
            AND
                contract_article.site_id = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_siteID
        );

        return $this->_db->getAllAssoc($sql);
	}
}


class ContractTemplatesDataGrid extends DataGrid
{
    protected $_siteID;


    // FIXME: Fix ugly indenting - ~400 character lines = bad.
    public function __construct($instanceName, $siteID, $parameters, $misc)
    {
        $this->_db = DatabaseConnection::getInstance();
        $this->_siteID = $siteID;
        $this->_assignedCriterion = "";
        $this->_dataItemIDColumn = 'contract.contract_id';

        $this->_classColumns = array(
            'Referentie' =>     array('select'         => 'contract.ref AS ref,'.
                                                       'contract.contract_id as contractID',
                                      'pagerRender'    => 'return \'<a href="'.CATSUtility::getIndexName().'?m=contracts&amp;a=showTemplate&amp;contractID=\'.$rsData[\'contractID\'].\'" >\'.htmlspecialchars($rsData[\'ref\']).\'</a>\';',
                                      'sortableColumn' => 'ref',
                                      'pagerWidth'     => 150,
                                      'pagerOptional'  => false,
                                      'alphaNavigation'=> true,
                                      'filter'         => 'contract.ref'),

            'Duration' =>       array('select'   => 'contract.duration AS duration',
                                     'sortableColumn'     => 'duration',
                                     'pagerWidth'    => 80,
                                     'alphaNavigation' => true,
                                     'filter'         => 'contract.duration'),
                                  
            'Honoraria' =>       array('select'   => 'contract.honoraria AS honoraria',
                                     'sortableColumn'     => 'honoraria',
                                     'pagerWidth'    => 80,
                                     'alphaNavigation' => true,
                                     'filter'         => 'contract.honoraria'),                                  

            'Contact' =>       array('select'   => 'contact.first_name AS contactFirstName,' .
                                                   'contact.last_name AS contactLastName,' .
                                                   'CONCAT(contact.last_name, contact.first_name) AS contactSort,' .
                                                   'contact.contact_id AS contactID',
                                     'pagerRender'      => 'return \'<a href="'.CATSUtility::getIndexName().'?m=contacts&amp;a=show&amp;contactID=\'.$rsData[\'contactID\'].\'">\'.StringUtility::makeInitialName($rsData[\'contactFirstName\'], $rsData[\'contactLastName\'], false, LAST_NAME_MAXLEN).\'</a>\';',
                                     'exportRender'     => 'return $rsData[\'contactFirstName\'] . " " .$rsData[\'contactLastName\'];',
                                     'sortableColumn'     => 'contactSort',
                                     'pagerWidth'    => 75,
                                     'alphaNavigation' => true,
                                     'filter'         => 'CONCAT(contact.first_name, contact.last_name)'),


            'Created' =>       array('select'   => 'DATE_FORMAT(contract.date_created, \'%m-%d-%y\') AS dateCreated',
                                     'pagerRender'      => 'return $rsData[\'dateCreated\'];',
                                     'sortableColumn'     => 'dateCreatedSort',
                                     'pagerWidth'    => 60,
                                     'filterHaving' => 'DATE_FORMAT(contract.date_created, \'%m-%d-%y\')'),

            'Modified' =>      array('select'   => 'DATE_FORMAT(contract.date_modified, \'%m-%d-%y\') AS dateModified',
                                     'pagerRender'      => 'return $rsData[\'dateModified\'];',
                                     'sortableColumn'     => 'dateModifiedSort',
                                     'pagerWidth'    => 60,
                                     'pagerOptional' => false,
                                     'filterHaving' => 'DATE_FORMAT(contract.date_modified, \'%m-%d-%y\')')
        );

        parent::__construct($instanceName, $parameters, $misc);
    }

    /**
     * Returns the sql statment for the pager.
     *
     * @return array Clients data
     */
    public function getSQL($selectSQL, $joinSQL, $whereSQL, $havingSQL, $orderSQL, $limitSQL, $distinct = '')
    {
        if ($this->getMiscArgument() != 0)
        {
            $savedListID = (int) $this->getMiscArgument();
            $joinSQL  .= ' INNER JOIN saved_list_entry
                                    ON saved_list_entry.data_item_type = '.DATA_ITEM_COMPANY.'
                                    AND saved_list_entry.data_item_id = contract.contract_id
                                    AND saved_list_entry.site_id = '.$this->_siteID.'
                                    AND saved_list_entry.saved_list_id = '.$savedListID;
        }
        else
        {
            $joinSQL  .= ' LEFT JOIN saved_list_entry
                                    ON saved_list_entry.data_item_type = '.DATA_ITEM_COMPANY.'
                                    AND saved_list_entry.data_item_id = contract.contract_id
                                    AND saved_list_entry.site_id = '.$this->_siteID;
        }

        $sql = sprintf(
            "SELECT SQL_CALC_FOUND_ROWS %s
                contract.company_id AS contractID,
                contract.company_id AS exportID,
                contract.contact_id AS contactID,
                contract.ref AS ref,
                contract.honoraria AS honoraria,
                contract.duration AS duration,
                contract.date_modified AS dateModifiedSort,
                contract.date_created AS dateCreatedSort,
            %s
            FROM
                contract
            LEFT JOIN contact
                ON contract.contact_id = contact.contact_id
            WHERE
                contract.site_id = %s
            AND
                contract.template = 1
            %s
            %s
            GROUP BY contract.contract_id
            %s
            %s
            %s",
            $distinct,
            $selectSQL,
            $this->_siteID,
            (strlen($whereSQL) > 0) ? ' AND ' . $whereSQL : '',
            $this->_assignedCriterion,
            (strlen($havingSQL) > 0) ? ' HAVING ' . $havingSQL : '',
            $orderSQL,
            $limitSQL
        );

        return $sql;
    }
}
?>
