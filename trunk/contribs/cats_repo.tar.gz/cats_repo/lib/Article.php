<?php
/**
 * CATS
 * Contracts Library
 *
 * Copyright (C) 2005 - 2007 Nijskens Raf.
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * @package    CATS
 * @subpackage Library
 * @copyright Copyright (C) 2005 - 2007 Nijskens Raf
 */


/**
 *  Article Library
 *  @package    CATS
 *  @subpackage Library
 */
class Article
{
    private $_db;
    private $_siteID;

    public $extraFields;


    public function __construct($siteID)
    {
        $this->_siteID = $siteID;
        $this->_db = DatabaseConnection::getInstance();
        $this->extraFields = new ExtraFields($siteID, DATA_ITEM_COMPANY);
    }


    /**
     * Adds an article to the database and returns its article ID.
     *
     * @param string Name
     * @param string Title
     * @param string Discription
     * @return new Article ID, or -1 on failure.
     */
    public function add($name, $title, $discription)
    {
        $sql = sprintf(
            "INSERT INTO article (
                name,
                title,
                discription,
                site_id,
                date_created,
                date_modified
            )
            VALUES (
                %s,
                %s,
                %s,
                %s,
                NOW(),
                NOW()
            )",
            $this->_db->makeQueryString($name),
            $this->_db->makeQueryString($title),
            $this->_db->makeQueryString($discription),
            $this->_siteID
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $articleID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $articleID);

        return $articleID;
    }

    /**
     * Updates an article.
     *
     * @param string Name
     * @param string Title
     * @param string Discription
     * @return boolean True if successful; false otherwise.
     */
    public function update($articleID, $name, $title, $discription)
    {
        $sql = sprintf(
            "UPDATE
                article
             SET
                name             = %s,
                title            = %s,
                discription      = %s,
                date_modified    = NOW()
            WHERE
                article_id = %s
            AND
                site_id = %s",
            $this->_db->makeQueryString($name),
            $this->_db->makeQueryString($title),
            $this->_db->makeQueryString($discription),
            $this->_db->makeQueryInteger($articleID),
            $this->_siteID
        );

        $preHistory = $this->get($articleID);
        $queryResult = $this->_db->query($sql);
        $postHistory = $this->get($articleID);

        if (!$queryResult)
        {
            return false;
        }

        $history = new History($this->_siteID);
        $history->storeHistoryChanges(DATA_ITEM_COMPANY, $articleID, $preHistory, $postHistory);

        return true;
    }

    /**
     * Removes an article and all associated records from the system.
     *
     * @param integer Article ID
     * @return void
     */
    public function delete($articleID)
    {
        /* Delete the company. */
        $sql = sprintf(
            "DELETE FROM
                article
            WHERE
                article_id = %s
            AND
                site_id = %s",
            $articleID,
            $this->_siteID
        );
        $this->_db->query($sql);

        $history = new History($this->_siteID);
        $history->storeHistoryDeleted(DATA_ITEM_COMPANY, $articleID);

        /* Find associated contacts. */
/*       $sql = sprintf(
            "SELECT
                contact_id AS contactID
            FROM
                contact
            WHERE
                company_id = %s
            AND
                site_id = %s",
            $articleID,
            $this->_siteID
        );
        $contactsRS = $this->_db->getAllAssoc($sql);
*/
        /* Find associated job orders. */
/*        $sql = sprintf(
            "SELECT
                joborder_id AS jobOrderID
            FROM
                joborder
            WHERE
                company_id = %s
            AND
                site_id = %s",
            $articleID,
            $this->_siteID
        );
        $jobOrdersRS = $this->_db->getAllAssoc($sql);
*/
        /* Delete associated contacts. */
/*        $contacts = new Contacts($this->_siteID);
        foreach ($contactsRS as $rowIndex => $row)
        {
            $contacts->delete($row['contactID']);
        }

        /* Delete associated job orders. */
/*        $jobOrders = new JobOrders($this->_siteID);
        foreach ($jobOrdersRS as $rowIndex => $row)
        {
            $jobOrders->delete($row['jobOrderID']);
        }
*/
    }

    /**
     * Returns all relevent article information for a given article ID.
     *
     * @param integer Article ID
     * @return array Article data
     */
    public function get($articleID)
    {
        $sql = sprintf(
            "SELECT
                article_id AS articleID,
                name,
                title,
                discription,
                date_created AS dateCreated
            FROM 
            	article
            WHERE
                article_id = %s
            AND
                site_id = %s",
            $this->_db->makeQueryInteger($articleID),
            $this->_siteID
        );

        return $this->_db->getAssoc($sql);
    }
    
     /**
     * Returns all relevent article information for all article ID's.
     *
     * @param integer Article ID
     * @return array Article data
     */
    public function getAll()
    {
        $sql = sprintf(
            "SELECT
                article_id AS articleID,
                name,
                title
            FROM 
            	article
            WHERE
                site_id = %s",
            $this->_siteID
        );

        return $this->_db->getAllAssoc($sql);
    }
    
    public function getCount()
    {
        $sql = sprintf(
            "SELECT
                COUNT(*) AS totalArticles
            FROM
                article
            WHERE
                article.site_id = %s",
            $this->_siteID
        );

        return $this->_db->getColumn($sql, 0, 0);
    }
}

class ArticlesDataGrid extends DataGrid
{
    protected $_siteID;


    // FIXME: Fix ugly indenting - ~400 character lines = bad.
    public function __construct($instanceName, $siteID, $parameters, $misc)
    {
        $this->_db = DatabaseConnection::getInstance();
        $this->_siteID = $siteID;
        $this->_assignedCriterion = "";
        $this->_dataItemIDColumn = 'article.article_id';

        $this->_classColumns = array(

            'Name' =>      array('select'         => 'article.name AS name,'.
                                                       'article.article_id as articleID',
                                     'sortableColumn'  => 'name',
                                     'pagerRender'     => 'return \'<a href="'.CATSUtility::getIndexName().'?m=contracts&amp;a=showArticle&amp;articleID=\'.$rsData[\'articleID\'].\'" >\'.htmlspecialchars($rsData[\'name\']).\'</a>\';',
                                     'pagerWidth'      => 20,
                                     'pagerOptional'   => false,
                                     'alphaNavigation' => true,
                                     'filter'         => 'article.name'),

            'title' =>     array('select'         => 'article.title AS title',
                                      'pagerRender'    => 'return \'<a href="'.CATSUtility::getIndexName().'?m=contracts&amp;a=showArticle&amp;articleID=\'.$rsData[\'articleID\'].\'" >\'.htmlspecialchars($rsData[\'title\']).\'</a>\';',
                                      'sortableColumn' => 'title',
                                      'pagerWidth'     => 40,
                                      'pagerOptional'  => true,
                                      'alphaNavigation'=> true,
                                      'filter'         => 'company.name'),

            'discription' =>        array('select'  => 'SUBSTRING(article.discription,1,200) AS discription',
                                     'sortableColumn'    => 'discription',
                                     'pagerWidth'   => 200,
                                     'alphaNavigation' => true,
                                     'pagerOptional'  => true,
                                     'filter'         => 'article.discription'),

			'Created' =>       array('select'   => 'DATE_FORMAT(article.date_created, \'%m-%d-%y\') AS dateCreatedSort',
                                     'pagerRender'      => 'return $rsData[\'dateCreated\'];',
                                     'sortableColumn'     => 'dateCreatedSort',
                                     'pagerWidth'    => 60,
                                     'filterHaving' => 'DATE_FORMAT(article.date_created, \'%m-%d-%y\')'),

            'Modified' =>      array('select'   => 'DATE_FORMAT(article.date_modified, \'%m-%d-%y\') AS dateModifiedSort',
                                     'pagerRender'      => 'return $rsData[\'dateModified\'];',
                                     'sortableColumn'     => 'dateModifiedSort',
                                     'pagerWidth'    => 60,
                                     'pagerOptional' => false,
                                     'filterHaving' => 'DATE_FORMAT(article.date_modified, \'%m-%d-%y\')')
        );

        parent::__construct($instanceName, $parameters, $misc);
    }
    
    /**
     * Returns the sql statment for the pager.
     *
     * @return array clients data
     */
    public function getSQL($selectSQL, $joinSQL, $whereSQL, $havingSQL, $orderSQL, $limitSQL, $distinct = '')
    {
		if ($this->getMiscArgument() != 0)
        {
            $savedListID = (int) $this->getMiscArgument();
            $joinSQL  .= ' INNER JOIN saved_list_entry
                                    ON saved_list_entry.data_item_type = '.DATA_ITEM_CONTACT.'
                                    AND saved_list_entry.data_item_id = article.article_id
                                    AND saved_list_entry.site_id = '.$this->_siteID.'
                                    AND saved_list_entry.saved_list_id = '.$savedListID;
        }
        else
        {
            $joinSQL  .= ' LEFT JOIN saved_list_entry
                                    ON saved_list_entry.data_item_type = '.DATA_ITEM_CONTACT.'
                                    AND saved_list_entry.data_item_id = article.article_id
                                    AND saved_list_entry.site_id = '.$this->_siteID;
        }

        $sql = sprintf(
            "SELECT SQL_CALC_FOUND_ROWS %s
                article.article_id AS articleID,
                article.article_id AS exportID,
                DATE_FORMAT(
                    article.date_modified, '%%m-%%d-%%y'
                ) AS dateModified,
                DATE_FORMAT(
                    article.date_created, '%%m-%%d-%%y'
                ) AS dateCreated,
            %s
            FROM
                article
            WHERE
                article.site_id = %s
            %s
            %s
            GROUP BY article.article_id
            %s
            %s
            %s",
            $distinct,
            $selectSQL,
            $this->_siteID,
            (strlen($whereSQL) > 0) ? ' AND ' . $whereSQL : '',
            $this->_assignedCriterion,
            (strlen($havingSQL) > 0) ? ' HAVING ' . $havingSQL : '',
            $orderSQL,
            $limitSQL
    	);

    	return $sql;
    }
}
?>
