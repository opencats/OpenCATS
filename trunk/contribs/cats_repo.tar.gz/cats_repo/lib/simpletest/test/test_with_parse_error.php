<?php
    // $Id: test_with_parse_error.php 424 2006-07-21 02:20:17Z will $
    
    class TestCaseWithParseError extends UnitTestCase {
        wibble
    }
    
?>