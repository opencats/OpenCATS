<?php
/**
 * CATS
 * Contracts Library
 *
 * Copyright (C) 2005 - 2007 Nijskens Raf.
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * @package    CATS
 * @subpackage Library
 * @copyright Copyright (C) 2005 - 2007 Nijskens Raf
 */
include_once('fpdf/fpdf.php');
include_once('fpdf/html2fpdf.php');
include_once('./lib/DataGrid.php');
/**
 *  Contracts Library
 *  @package    CATS
 *  @subpackage Library
 */
class Contract
{
    private $_db;
    private $_siteID;

    public $extraFields;


    public function __construct($siteID)
    {
        $this->_siteID = $siteID;
        $this->_db = DatabaseConnection::getInstance();
        $this->extraFields = new ExtraFields($siteID, DATA_ITEM_COMPANY);
    }


    /**
     * Adds a company to the database and returns its company ID.
     *
     * @param string Name
     * @param string Address line
     * @param string City
     * @param string State
     * @param string Zip code
     * @param string Phone 1
     * @param string Phone 2
     * @param string Url
     * @param string Key technologies
     * @param boolean Is company hot
     * @param string Company notes
     * @param integer Entered-by user
     * @param integer Owner user
     * @return new Company ID, or -1 on failure.
     */
    public function add($reference,$companyID,$contactID,$duration,$car,$carprice,$notice,$honoraria,$discription)
    {
        $sql = sprintf(
            "INSERT INTO contract (
                ref,
                company_id,
                contact_id,
                duration,
                car,
                car_price,
                notice,
                honoraria,
                discription_salary,
                site_id,
                date_created,
                date_modified
            )
            VALUES (
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                NOW(),
                NOW()
            )",
            $this->_db->makeQueryString($reference),
            $this->_db->makeQueryString($companyID),
            $this->_db->makeQueryString($contactID),
            $this->_db->makeQueryString($duration),
            $this->_db->makeQueryString($car),
            $this->_db->makeQueryString($carprice),
            $this->_db->makeQueryString($notice),
            $this->_db->makeQueryString($honoraria),
            $this->_db->makeQueryString($discription),
            $this->_siteID
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
    }

    /**
     * Updates a company.
     *
     * @param integer Company ID
     * @param string Name
     * @param string Address line
     * @param string City
     * @param string State
     * @param string Zip Code
     * @param string Phone 1
     * @param string Phone 2
     * @param string URL
     * @param string Key Technologies
     * @param boolean Is company hot
     * @param string Company notes
     * @param integer Owner user
     * @param integer Billing contact ID
     * @return boolean True if successful; false otherwise.
     */
    public function update($contractID,$reference,$companyID,$contactID,$duration,$car,$carprice,$notice,$honoraria,$discription)
    {
        $sql = sprintf(
            "UPDATE
                contract
             SET
                ref				= %s,
                company_id      = %s,
                contact_id      = %s,
                duration        = %s,
                car             = %s,
                car_price       = %s,
                notice          = %s,
                honoraria       = %s,
                discription_salary     = %s,
                date_modified   = NOW()
            WHERE
                contract_id = %s
            AND
                site_id = %s",
            $this->_db->makeQueryString($reference),
            $this->_db->makeQueryString($companyID),
            $this->_db->makeQueryString($contactID),
            $this->_db->makeQueryString($duration),
            $this->_db->makeQueryString($car),
            $this->_db->makeQueryString($carprice),
            $this->_db->makeQueryString($notice),
            $this->_db->makeQueryString($honoraria),
            $this->_db->makeQueryString($discription),
            $this->_db->makeQueryString($contractID),
            $this->_siteID
        );

        $preHistory = $this->get($contractID);
        $queryResult = $this->_db->query($sql);
        $postHistory = $this->get($contractID);

        if (!$queryResult)
        {
            return false;
        }

        $history = new History($this->_siteID);
        $history->storeHistoryChanges(DATA_ITEM_COMPANY, $contractID, $preHistory, $postHistory);

        return true;
    }

    /**
     * Removes a company and all associated records from the system.
     *
     * @param integer Company ID
     * @return void
     */
    public function delete($contractID)
    {
    	/* Delete the contract mappings. */
        $sql = sprintf(
            "DELETE FROM
                contract_article
            WHERE
                contract_id = %s
            AND
                site_id = %s",
            $contractID,
            $this->_siteID
        );
        $this->_db->query($sql);
        
        $sql = sprintf(
            "DELETE FROM
                contract_joborder
            WHERE
                contract_id = %s
            AND
                site_id = %s",
            $contractID,
            $this->_siteID
        );
        $this->_db->query($sql);
        
        /* Delete the contract. */
        $sql = sprintf(
            "DELETE FROM
                contract
            WHERE
                contract_id = %s
            AND
                site_id = %s",
            $contractID,
            $this->_siteID
        );
        $this->_db->query($sql);

        $history = new History($this->_siteID);
        $history->storeHistoryDeleted(DATA_ITEM_COMPANY, $contractID);

        /* Delete from saved lists. */
        $sql = sprintf(
            "DELETE FROM
                saved_list_entry
            WHERE
                data_item_id = %s
            AND
                site_id = %s
            AND
                data_item_type = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_siteID,
            DATA_ITEM_COMPANY
        );
        $this->_db->query($sql);

        /* Delete extra fields. */
        $this->extraFields->deleteValueByDataItemID($contractID);
    }

    /**
     * Returns all relevent company information for a given company ID.
     *
     * @param integer Company ID
     * @return array Company data
     */
    public function get($contractID)
    {
        $sql = sprintf(
            "SELECT
                contract.ref AS reference,
                contract.car AS car,
                contract.car_price AS car_price,
                contract.notice AS notice,
                contract.honoraria AS honoraria,
                contract.duration AS duration,
                contract.discription_salary AS discription_salary,
                contract.company_id AS companyID,
                contract.contact_id AS contactID,
				DATE_FORMAT(
                    contract.date_modified, '%%m-%%d-%%y'
                ) AS dateModified,
                DATE_FORMAT(
                    contract.date_created, '%%m-%%d-%%y'
                ) AS dateCreated
            FROM
                contract
            LEFT JOIN contact
                ON contract.contact_id = contact.contact_id
            WHERE
                contract.contract_id = %s
            AND
                contract.template = 0
            AND
                contract.site_id = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_siteID
        );

        return $this->_db->getAssoc($sql);
    }
    
    public function getCount()
    {
        $sql = sprintf(
            "SELECT
                COUNT(*) AS totalContracts
            FROM
                contract
            WHERE
                contract.site_id = %s
            AND
                contract.template = 0",
            $this->_siteID
        );

        return $this->_db->getColumn($sql, 0, 0);
    }

	public function addArticle($contractID,$articleID,$sequence)
	{
		$sql = sprintf(
            "INSERT INTO contract_article (
                contract_id,
                article_id,
                article_number,
                site_id
            )
            VALUES (
                %s,
                %s,
                %s,
                %s
            )",
            $this->_db->makeQueryString($contractID),
            $this->_db->makeQueryString($articleID),
            $this->_db->makeQueryString($sequence),
            $this->_siteID
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
	}
	
	public function checkArticle($contractID,$sequence)
	{
		$sql = sprintf(
            "SELECT
                contract_article.article_id AS articleID
            FROM
                contract_article
            WHERE
                contract_article.contract_id = %s
            AND
                contract_article.site_id = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_siteID
        );
        
        $queryResult = $this->_db->getAssoc($sql);
        return $queryResult['articleID'];
	}
	
	public function updateArticle($contractID,$sequence,$articleID)
	{
		$sql = sprintf(
			"UPDATE
                contract_article
             SET
                article_id		= %s
             WHERE
                contract_article.contract_id = %s
             AND
                contract_article.site_id = %s
             AND
                contract_article.article_number = %s",

            $this->_db->makeQueryString($articleID),
            $this->_db->makeQueryString($contractID),
            $this->_siteID,
            $this->_db->makeQueryString($sequence)
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
	}
	
	public function getArticles($contractID)
	{
		$sql = sprintf(
            "SELECT
                contract_article.article_id AS articleID,
                contract_article.article_number AS sequence
            FROM
                contract_article
            WHERE
                contract_article.contract_id = %s
            AND
                contract_article.site_id = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_siteID
        );

        return $this->_db->getAllAssoc($sql);
	}
	
	public function getArticleNumber($contractID,$articleID)
	{
		$sql = sprintf(
            "SELECT
                contract_article.article_number AS sequence
            FROM
                contract_article
            WHERE
                contract_article.contract_id = %s
            AND
                contract_article.article_id = %s
            AND
                contract_article.site_id = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_db->makeQueryInteger($articleID),
            $this->_siteID
        );
		$result = $this->_db->getAssoc($sql);
        return $result['sequence'];
	}
	
	public function addJobOrder($contractID,$jobOrderID,$sequence)
	{
		$sql = sprintf(
            "INSERT INTO contract_joborder (
                contract_id,
                joborder_id,
                joborder_number,
                site_id
            )
            VALUES (
                %s,
                %s,
                %s,
                %s
            )",
            $this->_db->makeQueryString($contractID),
            $this->_db->makeQueryString($jobOrderID),
            $this->_db->makeQueryString($sequence),
            $this->_siteID
        );

        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
	}

	public function setJobOrderNumber($contractID,$jobOrderID,$sequence)
	{
		$sql = sprintf(
            "UPDATE
                contract_joborder
            SET
                contract_joborder.joborder_number = %s
            WHERE
                contract_joborder.contract_id = %s
            AND
                contract_joborder.joborder_id = %s
            AND
                contract_joborder.site_id = %s",
            $this->_db->makeQueryInteger($sequence),
            $this->_db->makeQueryInteger($contractID),
            $this->_db->makeQueryInteger($jobOrderID),
            $this->_siteID
        );
        
        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
	}
	
	public function getJobOrderNumber($contractID,$jobOrderID)
	{
		$sql = sprintf(
            "SELECT
                contract_joborder.joborder_number
            FROM
            	contract_joborder
            WHERE
                contract_joborder.contract_id = %s
            AND
                contract_joborder.joborder_id = %s
            AND
                contract_joborder.site_id = %s",
            $this->_db->makeQueryInteger($contractID),
            $this->_db->makeQueryInteger($jobOrderID),
            $this->_siteID
        );
        
        
		$result = $this->_db->getAssoc($sql);

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $result['joborder_number'];
	}
	
	public function setContract($oldContractID,$contractID,$jobOrderID)
	{
		$sql = sprintf(
            "UPDATE
                contract_joborder
            SET
                contract_joborder.contract_id = %s
            WHERE
                contract_joborder.contract_id = %s
            AND
                contract_joborder.joborder_id = %s
            AND
                contract_joborder.site_id = %s",
            $this->_db->makeQueryInteger($oldContractID),
            $this->_db->makeQueryInteger($contractID),
            $this->_db->makeQueryInteger($jobOrderID),
            $this->_siteID
        );
        
        $queryResult = $this->_db->query($sql);
        if (!$queryResult)
        {
            return -1;
        }

        $contractID = $this->_db->getLastInsertID();

        $history = new History($this->_siteID);
        $history->storeHistoryNew(DATA_ITEM_COMPANY, $contractID);

        return $contractID;
	}
	
	public function getContract($jobOrderID)
    {
        $sql = sprintf(
            "SELECT
                contract_joborder.contract_id AS contractID,
                contract_joborder.joborder_number AS sequence,
                contract.ref AS ref
            FROM
                contract_joborder
            LEFT JOIN contract
                ON contract_joborder.contract_id = contract.contract_id
            WHERE
                contract_joborder.contract_id = contract.contract_id
            AND
                contract_joborder.joborder_id = %s
            AND
                contract.site_id = %s",
            $this->_db->makeQueryInteger($jobOrderID),
            $this->_siteID
        );

        return $this->_db->getAssoc($sql);
    }
}


class ContractsDataGrid extends DataGrid
{
    protected $_siteID;


    // FIXME: Fix ugly indenting - ~400 character lines = bad.
    public function __construct($instanceName, $siteID, $parameters, $misc)
    {
        $this->_db = DatabaseConnection::getInstance();
        $this->_siteID = $siteID;
        $this->_assignedCriterion = "";
        $this->_dataItemIDColumn = 'contract.contract_id';

        $this->_classColumns = array(
            'Referentie' =>     array('select'         => 'contract.ref AS ref,'.
                                                       'contract.contract_id as contractID',
                                      'pagerRender'    => 'return \'<a href="'.CATSUtility::getIndexName().'?m=contracts&amp;a=show&amp;contractID=\'.$rsData[\'contractID\'].\'" >\'.htmlspecialchars($rsData[\'ref\']).\'</a>\';',
                                      'sortableColumn' => 'ref',
                                      'pagerWidth'     => 80,
                                      'pagerOptional'  => false,
                                      'alphaNavigation'=> true,
                                      'filter'         => 'contract.ref'),

            'Duration' =>       array('select'   => 'contract.duration AS duration',
                                     'sortableColumn'     => 'duration',
                                     'pagerWidth'    => 50,
                                     'alphaNavigation' => true,
                                     'filter'         => 'contract.duration'),
                                  
            'Honoraria' =>       array('select'   => 'contract.honoraria AS honoraria',
                                     'sortableColumn'     => 'honoraria',
                                     'pagerWidth'    => 50,
                                     'alphaNavigation' => true,
                                     'filter'         => 'contract.honoraria'),                                  

            'Contact' =>       array('select'   => 'contact.first_name AS contactFirstName,' .
                                                   'contact.last_name AS contactLastName,' .
                                                   'CONCAT(contact.last_name, contact.first_name) AS contactSort,' .
                                                   'contact.contact_id AS contactID',
                                     'pagerRender'      => 'return \'<a href="'.CATSUtility::getIndexName().'?m=contacts&amp;a=show&amp;contactID=\'.$rsData[\'contactID\'].\'">\'.StringUtility::makeInitialName($rsData[\'contactFirstName\'], $rsData[\'contactLastName\'], false, LAST_NAME_MAXLEN).\'</a>\';',
                                     'exportRender'     => 'return $rsData[\'contactFirstName\'] . " " .$rsData[\'contactLastName\'];',
                                     'sortableColumn'     => 'contactSort',
                                     'pagerWidth'    => 50,
                                     'alphaNavigation' => true,
                                     'filter'         => 'CONCAT(contact.first_name, contact.last_name)'),


            'Created' =>       array('select'   => 'DATE_FORMAT(contract.date_created, \'%m-%d-%y\') AS dateCreated',
                                     'pagerRender'      => 'return $rsData[\'dateCreated\'];',
                                     'sortableColumn'     => 'dateCreatedSort',
                                     'pagerWidth'    => 20,
                                     'filterHaving' => 'DATE_FORMAT(contract.date_created, \'%m-%d-%y\')'),

            'Modified' =>      array('select'   => 'DATE_FORMAT(contract.date_modified, \'%m-%d-%y\') AS dateModified',
                                     'pagerRender'      => 'return $rsData[\'dateModified\'];',
                                     'sortableColumn'     => 'dateModifiedSort',
                                     'pagerWidth'    => 20,
                                     'pagerOptional' => false,
                                     'filterHaving' => 'DATE_FORMAT(contract.date_modified, \'%m-%d-%y\')')
        );

        parent::__construct($instanceName, $parameters, $misc);
    }

    /**
     * Returns the sql statment for the pager.
     *
     * @return array Clients data
     */
    public function getSQL($selectSQL, $joinSQL, $whereSQL, $havingSQL, $orderSQL, $limitSQL, $distinct = '')
    {
        if ($this->getMiscArgument() != 0)
        {
            $savedListID = (int) $this->getMiscArgument();
            $joinSQL  .= ' INNER JOIN saved_list_entry
                                    ON saved_list_entry.data_item_type = '.DATA_ITEM_COMPANY.'
                                    AND saved_list_entry.data_item_id = contract.contract_id
                                    AND saved_list_entry.site_id = '.$this->_siteID.'
                                    AND saved_list_entry.saved_list_id = '.$savedListID;
        }
        else
        {
            $joinSQL  .= ' LEFT JOIN saved_list_entry
                                    ON saved_list_entry.data_item_type = '.DATA_ITEM_COMPANY.'
                                    AND saved_list_entry.data_item_id = contract.contract_id
                                    AND saved_list_entry.site_id = '.$this->_siteID;
        }

        $sql = sprintf(
            "SELECT SQL_CALC_FOUND_ROWS %s
                contract.company_id AS contractID,
                contract.company_id AS exportID,
                contract.contact_id AS contactID,
                contract.ref AS ref,
                contract.honoraria AS honoraria,
                contract.duration AS duration,
                contract.date_modified AS dateModifiedSort,
                contract.date_created AS dateCreatedSort,
            %s
            FROM
                contract
            LEFT JOIN contact
                ON contract.contact_id = contact.contact_id
            WHERE
                contract.site_id = %s
            AND
                contract.template = 0
            %s
            %s
            GROUP BY contract.contract_id
            %s
            %s
            %s",
            $distinct,
            $selectSQL,
            $this->_siteID,
            (strlen($whereSQL) > 0) ? ' AND ' . $whereSQL : '',
            $this->_assignedCriterion,
            (strlen($havingSQL) > 0) ? ' HAVING ' . $havingSQL : '',
            $orderSQL,
            $limitSQL
        );

        return $sql;
    }
}


class PDF_Rotate extends HTML2FPDF
{
	var $angle=0;

	function Rotate($angle,$x=-1,$y=-1)
	{
	    if($x==-1)
	        $x=$this->x;
	    if($y==-1)
	        $y=$this->y;
	    if($this->angle!=0)
	        $this->_out('Q');
	    $this->angle=$angle;
	    if($angle!=0)
	    {
	        $angle*=M_PI/180;
	        $c=cos($angle);
	        $s=sin($angle);
	        $cx=$x*$this->k;
	        $cy=($this->h-$y)*$this->k;
	        $this->_out(sprintf('q %.5f %.5f %.5f %.5f %.2f %.2f cm 1 0 0 1 %.2f %.2f cm',$c,$s,-$s,$c,$cx,$cy,-$cx,-$cy));
	    }
	}
	
	function _endpage()
	{
	    if($this->angle!=0)
	    {
	        $this->angle=0;
	        $this->_out('Q');
	    }
	    parent::_endpage();
	}
}


class PDF extends PDF_Rotate	
{	
	function Header()
	{	
		if ($this->draft == true)
		{
			$this->SetFont('Arial','B',90);
    		$this->SetTextColor(235,235,235);
    		$this->RotatedText(60,200,'D R A F T',45);
		}
		$this->SetLeftMargin(10);
		$this->SetY(15);
	    //Arial bold 15
	    $this->SetFont('Arial','',10);
	    $this->SetTextColor(0,0,0);
	    //Title
	    $this->MultiCell(0,4,$this->header,0,1,'L',0);
	    $this->Image($this->companyLogo,177,14,17,17,'JPG');
	    //Draw Line
	    $this->Line(10,31,196,31);
	    $this->Ln(8);
 		$this->SetMargins(30,25,30);
	}
	
	function MyHeader($header,$draft = false,$companyLogo = NULL)
	{	
	    $this->header = $header;
	    $this->companyLogo = $companyLogo;
	    $this->draft = $draft;
	}
	
	function Footer()
	{
		$this->SetMargins(30,25,30);
		//Position at 1.5 cm from bottom
	    $this->SetY(-25);
	    //Arial italic 12
	    $this->SetFont('Arial','B',12);
	    //Page number
	    $this->Cell(0,10,$this->footer,0,0,'C');
	    //Line break
	    $this->Ln(4);
	    //Arial italic 8
	    $this->SetFont('Arial','',8);
	    //Page number
	    $this->Cell(0,10,"VG 1046/B",0,0,'C');
	    $this->Cell(0,10,$this->PageNo(),0,0,'R');
	}
	
	function MyFooter($footer)
	{
	    $this->footer = $footer;
	}
	
	function RotatedText($x,$y,$txt,$angle)
	{
	    //Text rotated around its origin
	    $this->Rotate($angle,$x,$y);
	    $this->Text($x,$y,$txt);
	    $this->Rotate(0);
	}

	function ChapterTitle($title)
	{
		$this->SetMargins(30,25,30);
		$this->Ln(10);
	    //Arial 12
	    $this->SetX(29);
	    $this->SetFont('Arial','B',12);
	    //Title
	    $this->Cell(0,6,$title,0,1,'L',0);
	    $this->SetX(30);
	    $this->Ln(4);
	}
	
	function ChapterBody($body)
	{
		$this->SetFont('Arial','',12);
	    //Output justified text
	    $this->WriteHTML($body);
	}
	
	function PrintChapter($title,$body)
	{
	    $this->ChapterTitle($title);
	    $this->ChapterBody($body);
	    
	}
}


?>
